# Geocoding catastale inverso — da civico/coordinata a foglio e particella

Questa procedura risponde a domande del tipo:

> "A quale foglio e particella catastale appartiene Via Vittorio Emanuele II, 29 a Lecce?"
> "Qual è la particella alle coordinate 40.3525, 18.1698?"

**Tutto il calcolo è LOCALE**: civici (ANNCSU) e catasto (Agenzia delle Entrate)
sono entrambi serviti da Cruscotto Italia. **Non interrogare MAI servizi esterni**
(WMS/WFS AGE, geoportale cartografico, Catasto online): non servono e non vanno usati.
Il dato è già tutto qui.

---

## Cosa è possibile e cosa no (leggere prima di promettere risultati)

Il civico ANNCSU è georeferenziato sul **fronte strada** (metodo "Ortofoto" nella
maggioranza dei casi), non sul tetto dell'edificio. Di conseguenza la coordinata di
un civico, quasi sempre, **cade dentro la particella-STRADA**, non dentro la
particella edificata.

Quindi la promessa corretta da fare all'utente è **B1**:

- **Foglio**: determinabile con certezza (il civico cade nel foglio giusto).
- **Particella esatta dell'immobile**: NON garantita al 100%. Si riportano le
  **particelle edificate adiacenti** al punto, ordinate per distanza, come candidate.

Non promettere "la particella esatta": riporta foglio (certo) + particelle candidate
(adiacenti, con distanza). È onesto e quasi sempre identifica correttamente l'immobile.

---

## Algoritmo (validato)

### 1. Civico → coordinate
Usa `anncsu_civico_search` (o `/data/anncsu_full/<istat>.json`) per ottenere lat/lon
del civico. Se ci sono più civici con lo stesso numero (es. "29" e "29/G"), elaborali
tutti o chiedi disambiguazione.

### 2. Scarica le particelle del comune
- **Comune monolitico** (tutti tranne Roma): `GET /data/catasto_full/<istat>_ple.geojson.gz`
  (≤ 20 MB). Decomprimi gzip → FeatureCollection di Polygon.
- **Roma (058091)**: è l'UNICO comune in modalità split (file troppo grande). Qui NON
  esiste il monolitico: devi prima sapere il foglio. Se non lo conosci, usa prima i
  **fogli** `GET /data/catasto_full/058091_map.geojson.gz` (CadastralZoning, leggero)
  per il point-in-polygon sul foglio, ricavi `<FFFF00>`, poi scarichi solo quel foglio
  `GET /data/catasto_full/058091_ple/H501_<FFFF00>.geojson.gz`.

### 3. Point-in-polygon (ray casting, nessuna libreria esterna)
Trova la feature la cui geometria contiene il punto (lon, lat). Attenzione: GeoJSON usa
ordine `[lon, lat]`.

```python
def point_in_ring(x, y, ring):
    inside = False; n = len(ring); j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside

def point_in_polygon(x, y, geom):
    if geom['type'] == 'Polygon':
        rings = geom['coordinates']
    elif geom['type'] == 'MultiPolygon':
        rings = [r for poly in geom['coordinates'] for r in poly]
    else:
        return False
    if not rings or not point_in_ring(x, y, rings[0]):
        return False
    return not any(point_in_ring(x, y, h) for h in rings[1:])  # esclude i buchi
```

### 4. Interpreta NATIONALCADASTRALREFERENCE (DUE formati nello stesso comune)
La property `NATIONALCADASTRALREFERENCE` ha due formati conviventi:

- con underscore: `E506_0259A0.1`  → BELFIORE=`E506`, foglio=`0259A0`, particella=`1`
- senza underscore: `E506A026200.1` → BELFIORE=`E506`, foglio=`A026200`, particella=`1`

```python
def parse_ref(ref):
    pre, part = ref.split('.', 1)
    if '_' in pre:
        bel, fog = pre.split('_', 1)
    else:
        bel, fog = pre[:4], pre[4:]
    return bel, fog, part
```

Le sedi stradali/acque hanno particella che inizia con `STRADA` o `ACQUA`
(es. `E506_0259F0.STRADA569`): NON sono immobili.

### 5. Se il match è una STRADA/ACQUA → particelle edificate adiacenti
Cerca, **nello stesso foglio**, le particelle non-strada più vicine al punto,
misurando la distanza minima dal **bordo** del poligono (non dal centroide).

```python
import math
def min_dist_m(x, y, geom):  # distanza minima punto-vertici, in metri approssimati
    if geom['type'] == 'Polygon':
        rings = geom['coordinates']
    else:
        rings = [r for poly in geom['coordinates'] for r in poly]
    best = float('inf')
    for ring in rings:
        for px, py in ring:
            d = math.hypot((px - x) * math.cos(math.radians(y)), py - y) * 111000
            best = min(best, d)
    return best
```

Filtra le feature dello stesso `foglio`, escludi `STRADA`/`ACQUA`, ordina per
`min_dist_m`, riporta le prime 3-5 come candidate con la loro distanza.

---

## Esempio reale validato: Via Vittorio Emanuele II, 29 — Lecce

1. `anncsu_civico_search` → civico "29" a `lat 40.352556, lon 18.169816`.
2. `GET /data/catasto_full/075035_ple.geojson.gz` (8.3 MB, monolitico, 68.426 particelle).
3. Point-in-polygon → match `E506_0259F0.STRADA569` → è la **sede stradale** del foglio **0259**.
4. Particelle edificate adiacenti nel foglio 0259 (distanza dal bordo):
   particella **1648** (~3 m), **1649** (~3 m), 730 (~12 m), 1650 (~15 m).

Risposta corretta all'utente:
> Il civico 29 di Via Vittorio Emanuele II (Lecce) ricade nel **foglio 0259**
> (BELFIORE E506). La coordinata cade sul fronte strada; le particelle edificate
> immediatamente adiacenti sono la **1648** e la **1649** (~3 m), quindi quasi
> certamente l'immobile corrisponde a una di queste.

---

## Cosa NON fare

- ❌ Non interrogare WMS/WFS o il geoportale cartografico AGE: il dato è locale e completo.
- ❌ Non promettere "la particella esatta" come fosse certa: il civico è sul fronte strada.
- ❌ Non usare il centroide per il ranking di vicinanza: usa la distanza dal bordo.
- ❌ Non dimenticare Roma: è l'unico comune split (niente `_ple.geojson.gz` monolitico).
