---
name: cruscotto-italia-workflow
version: 1.6.0
description: Cruscotto Italia MCP connector for Italian municipality data (7918 comuni). Sezioni dashboard: anagrafica, demografia, censimento, turismo, PNRR, ISPRA suolo/idro/rifiuti/aria, BDAP-MOP opere, SIOPE spese, ANAC contratti, MIUR scuole, ACI veicoli/incidenti, MEF redditi IRPEF, MEF patrimonio immobili PA, ANNCSU civici/strade, Min. Salute farmacie/parafarmacie/ospedali, GSE/MASE PUN ricarica EV, AGCOM BBmap banda larga FTTH, MIMIT carburanti, Min. Lavoro RUNTS Terzo Settore (ODV/APS/EF/IS/SMS/ETS, 5x1000). Use for any query mentioning Italian comuni by name ('Milano', 'Lecce vs Bari'), or terms like ISTAT, BDAP, SIOPE, ISPRA, IdroGEO, PNRR, ANAC, MEF, ANNCSU, MdS, GSE, PUN, AGCOM, FTTH, MIMIT, carburanti, benzina, gasolio, RUNTS, Terzo Settore, ODV, APS, ETS, volontariato, 5x1000, associazioni, fondazioni, imprese sociali, colonnine elettriche, copertura fibra, distributori. Covers name resolution, multi-comune, full ANNCSU endpoint, caveat per sezione.
---

# Cruscotto Italia workflow

Reference + workflow patterns for the Cruscotto Italia MCP connector.

- **Server**: `cruscotto-italia-mcp.piersoftckan.biz` (Cloudflare Worker)
- **Datasets integrati**: **19** (anagrafica, demografia, censimento profilo, turismo, PNRR, territorio ISPRA, opere BDAP-MOP, SIOPE multi-anno, scuole MIUR, aria ISPRA SNPA, parco veicoli ISTAT, incidenti ISTAT, iscrizioni ACI, redditi MEF, patrimonio immobili PA MEF DE, civici ANNCSU, sanità territoriale Ministero Salute, punti di ricarica EVSE PUN GSE/MASE, banda larga AGCOM BBmap, distributori carburanti MIMIT, enti Terzo Settore RUNTS Min. Lavoro)
- **Istituzioni fonte**: **15** (ANAC, BDAP, Italia Domani, ISTAT, ISPRA, MIUR, ACI, MEF Dipartimento Finanze, MEF Dipartimento Economia, Agenzia Entrate, Ministero della Salute, GSE / MASE, AGCOM, MIMIT, Ministero del Lavoro e Politiche Sociali)
- **Comuni coperti**: ~7.918

Il connettore espone **5 tool MCP**, di cui `comune_dashboard` è il workhorse — restituisce in una sola chiamata 22 sezioni di dati.

## Tool inventory (5 tool MCP)

I tool sono **deferred**: vanno caricati con `tool_search` prima di invocarli.

| Tool | Scopo | Input richiesto |
|---|---|---|
| `mcp_info` | Metadati server, freshness per source, manifest ETL | — |
| `search_comune` | Nome → codice ISTAT 6-digit | `query` (string) |
| `comune_dashboard` | Vista completa in una chiamata (22 sezioni: anagrafica, demografia, profilo, turismo, pnrr, territorio, opere, siope, scuole, aria, veicoli, redditi, immobili_pa, anncsu, sanita_mds, pun, agcom_bbmap, carburanti, runts, anac, bdap_kpi + metadati) | `istat_code` OR `denominazione` |
| `comune_opere_dettaglio` | Dettaglio completo opere pubbliche BDAP-MOP filtrate al 2025 (attivi o iniziati dal 2025-01-01). Lista per progetto con CUP, costi, finanziamenti, stato — non disponibile come dato aggregato in `dashboard.bdap_kpi` | `istat_code` |
| `anncsu_civico_search` | Query puntuali su civici ANNCSU con filtri server-side. Filtri: `odonimo` (substring match), `civico` (esatto). Default limit 50, max 500. Output con coordinate, quota altimetrica, metodo georef (GPS/Catasto/Ortofoto). Per dataset completo del comune usa endpoint REST `/data/anncsu_full/<istat>.json` | `istat_code` + filtri opzionali |

**Regola pratica**: per qualunque vista comunale, parti SEMPRE da `comune_dashboard`. Usa `comune_opere_dettaglio` solo se servono i singoli CUP filtrabili, e `anncsu_civico_search` solo per query puntuali su via/civico.

## Use case `anncsu_civico_search`

Domande tipiche dell'utente che attivano questo tool:

- **"Quale è la quota altimetrica di Via dei Mille civico 5 a Lecce?"**
  → `anncsu_civico_search({istat_code: "075035", odonimo: "MILLE", civico: "5"})`
  → Output: `results: [{lat, lon, odonimo, civico, quota_m, metodo_label}]`

- **"Esiste il civico 12 in Piazza San Marco a Venezia?"**
  → `anncsu_civico_search({istat_code: "027042", odonimo: "SAN MARCO", civico: "12"})`
  → Se `count: 0` → non esiste in ANNCSU (o non geo-ref). Se `count: 1` → sì, con coord.

- **"Quanti civici ha Via Roma a Matera?"**
  → `anncsu_civico_search({istat_code: "077014", odonimo: "ROMA", limit: 500})`
  → Output: `count: N`, results troncati a 500 se più di così. `_total_civici_comune` mostra il totale del comune.

- **"Mostrami i primi 20 civici di Cogne"** (senza filtri stradali)
  → `anncsu_civico_search({istat_code: "007021", limit: 20})`
  → Output con `_truncated: true` perché senza filtro è uno slice arbitrario.

**Caveat**:
- Lo shard ANNCSU full è disponibile per ~5.387 comuni su 7.918 (quelli con `pct_geo_ref` sufficiente). Se il comune non è coperto, `count: 0` con `_note` esplicativo.
- L'odonimo upstream è UPPERCASE senza accenti compositi. Il tool normalizza automaticamente apostrofi tipografici e spazi multipli, ma scrivi nomi semplici ("Roma", "Garibaldi", "Mille") senza preposizioni.
- Il civico è una stringa (non int): "12", "12A", "12-bis". Il match è esatto (non sub-string).
- L'esponente (`esponente: "A"`) è separato dal civico in ANNCSU: per "12A" cerca `civico: "12"` e poi filtra `esponente: "A"` dai risultati client-side se necessario.

## Endpoint HTTP diretti (non-MCP)

Lo stesso Worker espone alcuni endpoint REST pass-through R2 per dataset troppo grandi da serializzare in MCP tool result.

### `GET /data/anncsu_full/<istat>.json`

Snapshot completo dei civici ANNCSU per un comune (l'intero set, non i 1000 punti sample della dashboard).

- **Host**: `https://cruscotto-italia-mcp.piersoftckan.biz`
- **Cache**: 24h, CORS `*`, no auth
- **Copertura**: ~5.387 comuni (sottoinsieme di quelli con `pct_geo_ref` significativa)
- **Dimensioni tipiche**: Lecce ~4.7 MB / 47.917 civici; Roma ~50 MB / 515.815 civici (gzip ~4 MB); piccoli comuni qualche centinaio di KB
- **Shape**: identica a `dashboard.anncsu` ma con `punti[]` esteso e `_full: true`. Ogni punto: `{lat, lon, odo, civ, esp, quota, met}` dove `odo` = odonimo uppercase, `civ` = numero civico stringa, `esp` = subcivico/esponente lettera (es. "A", "B"), `met` = metodo georef (1=GPS, 3=catasto, 4=altra sorgente, 5=…)

**Quando usarlo**: richieste puntuali su strade/civici specifici (coordinate di un indirizzo, conteggio civici per via, ricerca odonimi). La sezione `anncsu` della dashboard ha solo 1000 punti sample che bastano per la mappa generale ma non per lookup di indirizzo.

**Pattern operativo "civico puntuale"** (es. "coordinate di via X numero Y a Z"):

1. `search_comune(query="Z")` → istat
2. HTTP GET `https://cruscotto-italia-mcp.piersoftckan.biz/data/anncsu_full/<istat>.json`
3. Filtra `punti` con `odo` contenente l'uppercase della via E `civ == "<numero>"`
4. Ritorna lat, lon, eventuale `esp`, `met`

Attenzione: gli odonimi sono UPPERCASE; "II", "III" vengono normalizzati a "SECONDO", "TERZO" (es. "Via Vittorio Emanuele II" è memorizzata come `VIA VITTORIO EMANUELE SECONDO`).

## Step 1 — Risolvere il nome del comune

L'utente dà un nome, i tool vogliono un codice ISTAT. Sempre `search_comune` prima, salvo che l'utente fornisca già il codice.

```
search_comune(query="Lecce") → istat_code "075035"
```

Tre cose da gestire:

**Omonimie.** Italia ha molti casi di nomi identici o quasi: "San Teodoro" (Sardegna e Sicilia), "Castel San Pietro" (Romagna e altrove), "Borgo San Lorenzo" vs "Borgo San Martino", ecc. `search_comune` ritorna i candidati ranked con `provincia` e `regione`: mostra la lista all'utente e chiedi quale, non tirare a indovinare. Se l'utente ha già specificato la provincia ("Oria (BR)", "Castelnuovo in provincia di Modena"), scegli direttamente.

**Comuni soppressi (fusioni/rinomine dal 2014 in poi).** Esempio: Pozza di Fassa, accorpata in San Giovanni di Fassa-Sèn Jan il 1 gennaio 2018. `search_comune` ritorna zero match. Fallback in ordine:

1. Cerca un **frammento distintivo** del nome ("Fassa" invece di "Pozza di Fassa", "Saluggia" invece di "Borgo d'Ale Saluggia")
2. Cerca **provincia + substring** se conosci l'area
3. Come ultima opzione, `web_search` per "fusione comune <nome>" e poi `search_comune` sul successore

Quando trovi il successore, esplicita all'utente: "Pozza di Fassa è stata fusa in San Giovanni di Fassa-Sèn Jan il 1 gennaio 2018; i dati per il territorio originale sono ora aggregati sotto il successore (ISTAT 022250)." Questo caveat conta per ogni serie storica.

**Errori di battitura e varianti dialettali.** `search_comune` è tollerante ma non infallibile. Su zero match con nome sospetto, prova varianti: con/senza apostrofi, vocali accentate, grafie alternative comuni (Cefalù/Cefalu, Forlì/Forli, Sant'Antonio/Santantonio).

## Step 2 — Pull della dashboard

```
comune_dashboard(istat_code="075035")
```

Risposta JSON corposa. Spesso viene paginata come file: in quel caso usa `bash`/grep/python per estrarre sezioni specifiche, evita di dumpare tutto. Vedi `references/dashboard_schema.md` per il key map completo — caricala la prima volta che lavori con la dashboard in una sessione, poi tienila a mente.

**Top-level keys (ordine reale)**:

- `_etl_version`, `_generated_at`, `_missing` — metadati
- `anagrafica` — identità, codice IPA, codice fiscale, KPI headline
- `demografia` — popolazione, piramide età, indici
- `profilo` — istruzione, lavoro, famiglie, mobilità, cittadinanza
- `turismo` — capacità ricettiva (comune) + flussi (provincia NUTS3)
- `pnrr` — progetti PNRR con comune Soggetto Attuatore
- `territorio` — suolo + rischio idrogeologico + rifiuti
- `opere` — opere pubbliche BDAP-MOP
- `siope` — spese **multi-anno** con `per_anno` keyed e `anno_default`
- `scuole` — anagrafe MIUR
- `aria` — qualità aria ISPRA SNPA (~604 comuni; spesso `null`)
- `veicoli` — **`veicoli.incidenti` qui dentro, non al top level**. Anche parco PRA e iscrizioni.
- `redditi` — dichiarazioni IRPEF MEF (tipicamente 2020–2024)
- `immobili_pa` — patrimonio immobiliare PA MEF DE 2022 (KPI + fino a 500 punti georeferenziati)
- `anncsu` — civici e strade Agenzia Entrate + ISTAT (KPI + 1000 punti sample; full via endpoint REST)
- `sanita_mds` — **NEW** sanità territoriale Ministero della Salute. Tre sotto-sezioni indipendenti, ciascuna `null` se assente: `farmacie` (~20.800 attive in 7.258 comuni, aggiornamento quotidiano, con KPI mix tipologia Ordinaria/Dispensario/Succursale/Stagionale e punti geo-referenziati), `parafarmacie` (~7.200 attive in 2.158 comuni, aggiornamento quotidiano), `ospedali` (1.272 stabilimenti in 736 comuni, anno 2023, ~213.000 posti letto totali con dettaglio per disciplina: degenza ordinaria, day hospital, day surgery, pagamento, e lista completa di stabilimenti con discipline annesse). Licenza IODL v2.0.
- `pun` — punti di ricarica per veicoli elettrici (EVSE) registrati sulla Piattaforma Unica Nazionale gestita da GSE per conto del MASE. ~66.619 PdR in 5.185 comuni (copertura 65,7%), aggiornamento **quotidiano** (~03:00 UTC). `kpi` aggregato con totale, attivi/non-attivi, mix per categoria potenza (Slow ≤7kW / Quick 7-22kW / Fast 22-50kW / HPC 50-150kW / Ultra fast >150kW), distribuzione corrente (AC/DC), potenza totale kW. `punti[]` sample con id_evse, lat, lon, indirizzo, cap, stato, tipo_parcheggio (vocabolario OCPI: ON_STREET/PARKING_LOT/UNDERGROUND_GARAGE), potenza_categoria, potenza_w, corrente, restrizioni (vocabolario OCPI), servizi_vicini (OCPI), orario. **Licenza CC BY 4.0 ex art. 52 c.2 D.Lgs 82/2005 (CAD)** — open data di default delle PA con attribuzione a GSE.
- `runts` — enti del Terzo Settore iscritti al Registro Unico Nazionale (Min. Lavoro e Politiche Sociali, D.Lgs 117/2017 art. 53). **145.898 enti** in **7.547 comuni** (copertura 95,3%), aggiornamento **quotidiano** (file XLSX bulk via PostBack ASP.NET). `kpi` con `n_totale`, `mix_sezione` (6 chiavi: ODV organizzazioni di volontariato, APS associazioni di promozione sociale, EF enti filantropici, IS imprese sociali, SMS società di mutuo soccorso, ETS altri enti del Terzo Settore — ordinato per count desc), `n_5x1000` + `pct_5x1000` (~52% nazionale), `n_rete_associativa` (~0,04% nazionale), `iscrizioni_per_anno` (dict anno→count). `enti[]` con `cf`, `rep` (id RUNTS), `denom`, `sez`, `rapp`, `rete`, `x1000`, `data_iscr` (ISO YYYY-MM-DD). **Cap 5000 enti** ordinati per `data_iscr` DESC; se cappato presenti `_enti_truncated:true`, `_enti_total:N`, `_enti_cap:5000` (es. Roma 6.616 → 1.616 più vecchi troncati). La sezione **MAI null** (anche comuni con 0 enti: `n_totale:0`, `enti:[]`). **Licenza**: dato pubblico per legge ex D.Lgs 117/2017 + D.Lgs 36/2006 (Direttiva PSI / Open Data).
- `anac` — aggregato contratti pubblici
- `bdap_kpi` — KPI BDAP-MOP per stato/settore

## Step 3 — Estrai quello che ha chiesto l'utente

Map intent → sottosezione:

- "incidenti", "morti", "feriti", "sinistri" → `veicoli.incidenti`
- "auto", "parco veicoli", "Euro 6", "tasso motorizzazione" → `veicoli.parco_veicoli`
- "nuove immatricolazioni", "elettriche", "ibride" → `veicoli.iscrizioni`
- "rifiuti", "raccolta differenziata" → `territorio.rifiuti`
- "frane", "alluvioni", "rischio idrogeologico" → `territorio.rischio_idrogeologico`
- "consumo di suolo" → `territorio.suolo`
- "PM10", "PM2.5", "qualità dell'aria" → `aria` (controlla `null` prima)
- "redditi", "IRPEF", "addizionale comunale" → `redditi`
- "scuole", "istituti" → `scuole`
- "opere pubbliche", "lavori pubblici", "cantieri", "BDAP" → `opere` o `bdap_kpi` (per dettaglio filtrato 2025 → `comune_opere_dettaglio` tool)
- "PNRR", "Italia Domani", "ReGiS" → `pnrr`
- "appalti", "gare", "ANAC", "CIG" → `anac` aggregato (count, importo totale, top_cpv, range date)
- "spese", "SIOPE", "bilancio" → `siope.per_anno[<anno>]`
- "turismo", "alberghi", "stelle" → `turismo.capacita_comune`
- "arrivi", "presenze", "permanenza media" → `turismo.flussi_provincia` (con caveat NUTS3)
- "patrimonio", "immobili pubblici", "beni immobili", "fabbricati PA", "demanio" → `immobili_pa`
- "civico", "via", "strada", "odonimo", "coordinate di indirizzo" → tool dedicato `anncsu_civico_search` (filtri server-side odonimo/civico, limit) per query puntuali, oppure sezione `anncsu` di `comune_dashboard` (KPI + 1000 punti sample), oppure endpoint REST `/data/anncsu_full/<istat>.json` per il dataset completo del comune
- "farmacie", "farmacia", "parafarmacie", "dispensari" → `sanita_mds.farmacie` o `sanita_mds.parafarmacie`
- "ospedali", "posti letto", "policlinico", "presidio ospedaliero", "stabilimento ospedaliero", "discipline", "reparti", "PL", "degenza", "day hospital", "day surgery" → `sanita_mds.ospedali`
- "colonnine", "colonnine elettriche", "punti di ricarica", "ricarica veicoli elettrici", "EVSE", "stazioni di ricarica", "mobilita elettrica", "auto elettriche infrastrutture", "GSE", "PUN", "Tesla Supercharger", "Ionity", "fast charging", "HPC", "Ultra fast" → `pun`
- "associazioni", "associazione", "volontariato", "Terzo Settore", "ETS", "RUNTS", "ODV", "APS", "imprese sociali", "fondazioni filantropiche", "enti filantropici", "mutuo soccorso", "5x1000", "5 per mille", "cinque per mille", "rete associativa", "no profit", "non profit", "non-profit" → `runts`
- "ASL", "ATS", "azienda sanitaria" → **non coperto direttamente**. Posti letto ospedalieri sono per stabilimento (codice struttura MdS), non per ASL. Se l'utente chiede dati ASL/ATS, dillo onestamente: non c'è una sezione dedicata in dashboard.

Se la sezione è `null` o in `_missing`, dillo esplicitamente. Non inventare.

## Multi-comune workflow

Confronto fra due o più comuni:

1. Risolvi tutti gli ISTAT in parallelo via `search_comune` (uno per nome)
2. Conferma omonimie con l'utente prima di procedere
3. `comune_dashboard` per ognuno (le chiamate possono andare in parallelo)
4. Estrai la stessa sotto-sezione da ogni risposta
5. Presenta il confronto

Su comuni con popolazione molto diversa (es. 14k vs 4k), preferisci metriche **per-capita** o **per-10k-ab** — di solito già presenti (`morti_per_10k_ab`, `feriti_per_10k_ab`, `tasso_motorizzazione_per_1000_ab`, `rd_pct`). Conteggi grezzi soli fuorviano.

Se almeno uno dei comuni nel confronto è il risultato di una fusione recente, nota quali anni sono pre/post-fusione: la serie storica può concatenare due ambiti territoriali diversi.

## Data freshness — cosa dire all'utente

Ogni sezione ha la sua cadenza. Esponi `_anno_dati_*`, `anno`, `_snapshot_date` o `data_estrazione` quando citi numeri, specie su dati ad alta frequenza.

| Sezione | Cadenza | Lag tipico |
|---|---|---|
| `demografia` (POSAS) | Annuale (rif. 1 gen) | ~3 mesi |
| `veicoli.parco_veicoli` (ISTAT 41_993) | Annuale | rilascio dicembre per anno precedente |
| `veicoli.incidenti` (ISTAT 41_983) | Annuale | rilascio luglio per anno precedente |
| `veicoli.iscrizioni` (ACI LOD) | Annuale | rilascio gennaio |
| `territorio.suolo` (ISPRA SNPA) | Annuale | metà anno (Rapporto SNPA) |
| `territorio.rifiuti` (Catasto ISPRA) | Annuale | metà anno |
| `redditi` (MEF Dip. Finanze) | Annuale | ~5–6 mesi dopo anno fiscale |
| `pnrr` (Italia Domani / ReGiS) | Snapshot periodici | vedi `data_estrazione` |
| `siope` (BDAP CKAN) | Mensile cumulativo, multi-anno | anno corrente parziale (vedi `parziale: true`) |
| `anac` | Periodico | controlla `last_award_date` |
| `aria` (ISPRA SNPA) | Live dove disponibile | controlla `_generated_at` |
| `immobili_pa` (MEF DE) | Snapshot statico al 31/12/2022 | `anno_rilevazione: 2022` |
| `anncsu` (Agenzia Entrate + ISTAT) | Mensile | vedi `_snapshot_date` |
| `sanita_mds.farmacie` (Min. Salute) | Quotidiano | filtro attive su `data_fine_validita`; URL CSV cambia ogni giorno (es. `FRM_FARMA_5_YYYYMMDD.csv`) |
| `sanita_mds.parafarmacie` (Min. Salute) | Quotidiano | come sopra (`FRM_PFARMA_7_YYYYMMDD.csv`) |
| `sanita_mds.ospedali` (Min. Salute) | Annuale | dato fermo all'anno 2023 (`anno_dati: 2023`), rilasciato luglio 2025 |
| `pun` (GSE / MASE) | **Quotidiana** | shard rigenerati ogni giorno ~03:00 UTC dal CSV ufficiale |
| `agcom_bbmap` (AGCOM) | **Trimestrale** | dato corrente al 31/12/2025 (rilascio 10/02/2026); aggiornamento ogni ~3 mesi dal CSV ufficiale ArcGIS |
| `carburanti` (MIMIT) | **Quotidiana** | "Prezzo alle 8 di mattina" — snapshot rigenerato ogni giorno dai gestori distributori ex art. 51 L. 99/2009 |
| `runts` (Min. Lavoro) | **Quotidiana** | XLSX bulk `YYYYMMDD_iscritti_v1.0.xlsx` ricostruito quotidianamente dal Min. Lavoro; ETL Cruscotto settimanale (lunedì 04:00) — il delta tra snapshot Min. Lavoro e snapshot Cruscotto è max 6 giorni |

Per freshness completa chiama `mcp_info`.

## Caveat conosciuti (sempre da segnalare quando rilevante)

- **I flussi turistici sono NUTS3 (provinciali), non comunali.** ISTAT non pubblica arrivi/presenze per singolo comune. La dashboard espone i flussi provinciali con un `_warning` field: passa quel warning verbatim, non spacciare i numeri come comunali.
- **Mobilità ferma al 2019.** `profilo.mobilita` mostra pendolarismo dall'ultima onda del censimento permanente disponibile (2019). La dashboard segnala con `_warning` — non presentarli come attuali.
- **La sezione PNRR copre solo progetti dove il comune è Soggetto Attuatore.** Progetti realizzati sul territorio da altri enti (Regioni, Ministeri, GSE, ASL, università) NON sono inclusi — il dataset upstream non ha mapping affidabile progetto↔territorio. Dichiaralo esplicitamente quando rispondi a "quanti soldi PNRR arrivano a <comune>".
- **Qualità dell'aria sparsa.** Solo ~604 comuni su ~7900 hanno stazioni. Se `aria` è `null`, dì "nessuna stazione ISPRA SNPA in questo comune", non inventare.
- **ANNCSU: 3 livelli di accesso a seconda della query.** (1) Sezione `anncsu` di `comune_dashboard` per KPI aggregati + 1000 punti sample (rappresentativo, NON esaustivo). (2) Tool `anncsu_civico_search` per query puntuali con filtri server-side su odonimo/civico (limit 50 default, max 500): scelta consigliata per "qual è il civico X in via Y", "quante quote per Via Z". (3) Endpoint REST `/data/anncsu_full/<istat>.json` per il dataset completo del comune (Roma 50 MB, Lecce 4.7 MB — solo se serve elaborarli interamente).
- **`immobili_pa` con sampling stratificato.** I `punti` sono cappati a ~500 con sampling stratificato per categoria (su Roma/Milano la copertura è qualitativamente rappresentativa, non esaustiva). I KPI invece sono calcolati sul totale degli immobili dichiarati. Per piccoli comuni senza immobili PA dichiarati, `immobili_pa` può essere `null`.
- **ANAC `_period_files` (TODO upstream)**: la finestra temporale dei contratti non è ancora propagata al dashboard. Per il periodo esatto controlla `first_award_date` e `last_award_date` nella sezione `anac`.
- **Comuni bilingui / fusi (ACI)**: per le iscrizioni veicolari ACI le anomalie sono note solo per Bolzano, Trento, Aosta (immatricolazioni cross-border); il dataset gestisce 32 casi speciali (bilingui + fusioni) per chiudere il match.
- **`sanita_mds.ospedali` ferma al 2023.** Il Ministero della Salute rilascia annualmente i posti letto ospedalieri (con ~2 anni di ritardo: il dataset 2023 è uscito a luglio 2025). Non spacciare il numero come attuale: dichiara sempre l'anno di riferimento. Per i posti letto privati (case di cura accreditate) i dati MdS sono inclusi nello stesso file ma marcati con `tipo_struttura` distinto (es. "Casa di cura accreditata").
- **`sanita_mds.farmacie` può avere coordinate errate** (geocoding upstream MdS imperfetto). Tasso outlier osservato ~0.24% (es. 2 farmacie su 834 a Roma con coordinate in altra provincia). Le farmacie sono comunque assegnate al `cod_comune` ISTAT corretto, quindi i KPI per comune sono affidabili; gli outlier si vedono solo sulla mappa. La sezione `kpi.n_outlier_coordinate` conteggia solo gli outlier fuori bbox Italia (35-47°N, 6-19°E) — non quelli fuori provincia.
- **`sanita_mds.parafarmacie` copertura limitata.** Solo 2.158 comuni hanno parafarmacie (vs 7.258 con farmacie), concentrate in centri urbani medio-grandi. Per piccoli comuni `parafarmacie: null` è la norma.
- **Min. Salute non espone i CUP / prenotazioni.** Il dataset MdS è anagrafico (farmacie, ospedali, posti letto) — non include tempi di attesa, ticket, esenzioni, ricoveri, prestazioni erogate. Per quei dati l'utente dovrebbe rivolgersi ai portali regionali o ad Agenas. Non improvvisare.
- **`sanita_mds` integrato come bundle unico, ma le sezioni sono indipendenti.** Un comune può avere `farmacie` popolato e `ospedali: null` (caso più comune: piccoli comuni con farmacia rurale ma senza ospedale). Controlla ogni sotto-sezione prima di accederla.
- **`pun` copertura parziale ma quotidiana.** Solo **5.185 comuni su 7.918** hanno punti di ricarica registrati sulla PUN (65,7%); i comuni piccoli e/o di montagna hanno spesso `pun: null`. Il dato è però **aggiornato quotidianamente** (~03:00 UTC) dal CSV ufficiale GSE: per richieste su "punti aggiunti questa settimana" o trend recenti, il dato è affidabile e fresco.
- **`pun.punti[]` è un sample fino a 500.** Per comuni con migliaia di PdR (Roma 3680, Milano 3045, Napoli 1199, Torino 1144, Genova 740) i KPI aggregati sono calcolati sul **totale**, ma `punti[]` è cappato a 500 con sampling stratificato per categoria potenza. Non garantisce la lista completa per comuni urbani.
- **`pun` vocabolari OCPI.** I campi categoriali (`tipo_parcheggio`, `restrizioni`, `servizi_vicini`) seguono lo standard **OCPI** (Open Charge Point Interface, std europeo per interoperabilità ricarica EV). Es. `tipo_parcheggio` può essere `ON_STREET`, `PARKING_LOT`, `UNDERGROUND_GARAGE`, `PARKING_GARAGE`, `ROOFTOP_CARPARK`, oppure `null` quando il CPO non lo dichiara (frequente, ~57% null su Roma). `restrizioni` e `servizi_vicini` sono stringhe multi-valore con i codici OCPI separati da `- ` (es. `"EV_ONLY- PLUGGED- DISABLED"`). NON inventare valori tipo "pubblico/privato/riservato".
- **`pun` 14 punti unmatched su 66.619 totali (0.02%).** Sono errori di geocoding upstream lato GSE (città non riconducibili a un comune ISTAT). Non c'è modo di recuperarli senza informazioni extra; il dataset è considerato 99.98% coperto.
- **`pun.kpi.potenza_tot_kw` è massima erogabile, non istantanea.** Somma della potenza nominale dichiarata di ciascuna EVSE installata. Non rappresenta il consumo energetico, né la potenza simultanea (un comune con 100 PdR Slow da 22kW ha `potenza_tot_kw: 2200` indipendentemente da quanti siano in uso). Per stime energetiche serve incrociare con dati TERNA/GSE non disponibili a questo livello.
- **`agcom_bbmap` copertura nazionale completa.** A differenza di altre fonti, AGCOM BBmap copre **tutti i 7.896 comuni italiani (100%)**. Nessun comune ha `agcom_bbmap: null`. Per comuni piccolissimi (es. Morterone con 22 famiglie) la copertura FTTH è realisticamente 0% e i campi `famiglie_ftth` / `punti_dichiarati_ftth` sono `null` (non zero).
- **`agcom_bbmap.kpi.copertura_ftth_desi_pct` è la metrica UE ufficiale.** Calcolata secondo metodologia DESI (Digital Economy and Society Index) della Commissione Europea. La metrica `copertura_ftth_20m_pct` è più stringente (richiede FTTH entro 20m dall'edificio). Quando l'utente chiede "copertura fibra", default su DESI; usa la 20m solo se chiede "fibra a casa" o "FTTH effettivo". Sempre cita `confidenza_desi_pct` quando rilevante (sotto 70% = dato debole).
- **`agcom_bbmap` non include geometrie.** Le polilinee delle strade FTTH/rame sono nel FeatureServer ArcGIS AGCOM (192k+ segmenti per Roma, troppo voluminoso per shard). Per la mappa di dettaglio per strada, costruisci client-side il deep-link `https://geo.agcom.it/agcomapps/BB4/BB4_BBwired_na_app16_4/?center={lon},{lat}&level={N}` (level 12-15 in base alla taglia del comune). Il campo `mappa_ufficiale.url` nello shard ha già l'URL base; aggiungi `?center=lon,lat&level=N` con coordinate dal `anagrafica`.
- **`agcom_bbmap` aggiornamento trimestrale.** Il rilascio AGCOM avviene tipicamente 30-45 giorni dopo la fine di ogni trimestre. Il campo `_data_period` (es. "31/12/2025") indica la data di stato del dato; il `_generated_at` indica quando è stato fatto l'ETL. Per richieste su trend "ultimi 3 mesi" il dato è coerente; per "ultima settimana" serve fonte real-time non disponibile (operatori non pubblicano in continuo).
- **`carburanti` copertura 5.450/7.896 comuni (69%).** I ~2.450 comuni senza distributore sono micro-comuni di montagna o piccoli paesi rurali (es. Morterone). Per richieste su comuni senza shard (`carburanti: null`), suggerisci il **comune limitrofo più popolato** dove esiste l'impianto. Non c'è un fallback automatico cross-confine: l'API spaziale `https://carburanti.mise.gov.it/ospzApi/search/zone` (raggio 5km, body `{points:[{lat,lng}], fuelType:"2-1"}`) può essere usata client-side per il caso d'uso "qual è il prezzo più basso vicino a me".
- **`carburanti.kpi.prezzo_medio` su Stradale + Autostradale insieme.** La media comunale comprende **tutti** gli impianti del comune, anche quelli autostradali (Tipo Impianto = "Autostradale"), che hanno prezzi tipicamente 15-30% più alti. Per comuni attraversati da autostrade (es. Roma con 18 impianti autostradali su 936), questo gonfia la media. Quando rilevante, usa `kpi.n_stradali` e `kpi.n_autostradali` per qualificare; in alternativa filtra `punti[]` per `tipo == "Stradale"` e ricalcola.
- **`carburanti.kpi.prezzo_min` è informativo ma volatile.** Riflette il singolo impianto più economico nel comune al momento del snapshot. Cambia spesso (a volte di giorno in giorno per offerte locali). Citalo solo come orientativo, non come benchmark stabile. Per il benchmark stabile usa `prezzo_medio`.
- **`carburanti` 7 carburanti core, premium in `prezzi_extra`.** I core sono `benzina_self`, `benzina_serv`, `gasolio_self`, `gasolio_serv`, `gpl`, `metano`, `hvo`. I premium proprietari (Shell V-Power, Hi-Q Diesel, Supreme Diesel, Blue Diesel, Gasolio Premium) sono in `punti[N].prezzi_extra` come dizionario opzionale — NON entrano nei `prezzo_medio` per coerenza statistica.
- **`carburanti.kpi.freshness_pct` indica qualità del prezzo, non dell'anagrafica.** Misura la % di impianti con `ultimo_aggiornamento` <=7 giorni. Sotto 70% segnala che molti gestori non aggiornano il prezzo da settimane → media meno affidabile. Sopra 90% = dato robusto. Citalo quando significativamente diverso o quando rispondi a "qual è il prezzo aggiornato".
- **`carburanti.punti[]` no cap.** A differenza di `pun` (cappato 500) e `immobili_pa` (cappato 500), `carburanti.punti[]` contiene **tutti** gli impianti del comune (Roma worst case ~936, sotto 1 MB). Sicuro per query puntuali "qual è il distributore più vicino a [indirizzo]" se il frontend conosce le coordinate utente.
- **Aggregati nazionali `carburanti/_nazionale.json` separati.** Per il calcolo del delta vs media nazionale/regionale, il frontend deve fare fetch separato a `https://cruscotto-italia-data.r2.dev/carburanti/_nazionale.json` (NON è nello shard dashboard per ragioni di volume). Schema: `{nazionale: {benzina_self, ...}, regionale: {Lombardia: {...}, ...}}` — medie pre-calcolate dall'ETL.
- **`runts` copertura ampia ma non totale.** 7.547 comuni su 7.918 (95,3%) hanno almeno un ente del Terzo Settore registrato. I 371 comuni residui (~4,7%) sono comuni piccolissimi/montani: per loro `runts.kpi.n_totale == 0` e `runts.enti == []` (la sezione NON è `null` per consistenza UX — distingui `n_totale==0` da `runts is null`). Mai dire "comune non coperto da RUNTS": dì invece "nessun ente del Terzo Settore registrato con sede legale in questo comune".
- **`runts.enti[]` cappato a 5000 ordinati per `data_iscr` DESC.** Solo Roma (6.616 enti) viene troncata di 1.616 unità — quelli più vecchi. Per tutti gli altri comuni l'array è completo. Se cappato: presenti `_enti_truncated:true`, `_enti_total:N`, `_enti_cap:5000`. I KPI (`mix_sezione`, `n_5x1000`, `iscrizioni_per_anno`, ecc.) sono calcolati sul totale, NON sulla lista cappata: usa i KPI per le domande aggregate, la lista solo per il dettaglio puntuale.
- **`runts` riguarda la sede legale, non l'operatività.** Un ente con sede legale a Lecce che opera in tutta la Puglia compare SOLO nello shard Lecce. Per domande tipo "quante associazioni operano sul territorio" rispondi onestamente: il RUNTS registra la sede legale, non la copertura operativa. Per Roma in particolare il bias è significativo (sede legale di ETS nazionali tipo ANPAS, AVIS Nazionale, Banco Alimentare). 
- **`runts.kpi.iscrizioni_per_anno` ha un picco 2022 dovuto alla trasmigrazione.** Il RUNTS è entrato in vigore il 23 novembre 2021 e i registri preesistenti (Volontariato, APS, Onlus) sono stati migrati massivamente nel 2022. Circa il **52% del totale enti nazionali** ha `data_iscr` nel 2022 — non è un picco "vero" di nuove costituzioni ma un artefatto di trasmigrazione. Per trend reali di crescita del Terzo Settore guarda 2023+. Le iscrizioni dell'anno corrente (es. 2026 al 15/05) sono ovviamente **parziali** — dichiaralo quando rilevante.
- **`runts.kpi.mix_sezione` segue lo schema D.Lgs 117/2017.** Le 6 sezioni hanno definizioni giuridiche precise: **ODV** (Org. di Volontariato, ex L. 266/1991, attività di interesse generale prestate prevalentemente da volontari), **APS** (Assoc. Promozione Sociale, ex L. 383/2000, finalità sociali con presenza prevalente di soci attivi non retribuiti), **EF** (Enti Filantropici, novità RUNTS — fondazioni che erogano risorse a terzi), **IS** (Imprese Sociali, ex D.Lgs 112/2017, soggette anche al Registro Imprese), **SMS** (Società di Mutuo Soccorso, ex L. 3818/1886 ancora vigente), **ETS** (Altri Enti del Terzo Settore — categoria residuale di chi non rientra nelle 5 sopra). NON confonderle: chiamare "ODV" un'APS è errore non solo lessicale ma di inquadramento normativo.

## File di riferimento

- `references/dashboard_schema.md` — Key map completo della response `comune_dashboard`, con significato dei campi e unità tipiche. Caricala la prima volta che lavori con la struttura dashboard in una sessione.
