# Dashboard schema reference (v1.0)

Key map completo della response `comune_dashboard`. Da usare per estrarre campi specifici. Le chiavi top-level sono elencate nell'ordine restituito dall'API. I nomi tra `backtick` sono chiavi JSON letterali.

Server di riferimento: `cruscotto-italia-mcp.piersoftckan.biz` — MCP **v0.5.0** (14 dataset, 10 istituzioni, ~7.918 comuni).

## Metadata

- `_etl_version` — versione pipeline ETL
- `_generated_at` — timestamp ISO 8601 di questa response
- `_missing` — array di sezioni non disponibili per il comune (es. `["aria"]`)

Sempre controllare `_missing` prima di dichiarare una sezione mancante: potrebbe semplicemente non essere stata generata per quel comune.

## `anagrafica`

Identità di base. Chiavi: `istat_code`, `denominazione`, `provincia`, `regione`, `codice_ipa`, `codice_fiscale`, `nome_categoria`, `codice_catastale`, `kpi`.

`kpi` è un riassunto quick-glance con `contratti`, `opere`, `spese_siope`, `coesione`, `popolazione`. Spesso `null` per comuni più piccoli.

## `demografia`

Fonte: ISTAT POSAS (popolazione residente per età e sesso). Riferimento: 1 gennaio (stima anno corrente).

- `popolazione_totale`, `maschi`, `femmine`, `pct_maschi`, `pct_femmine`
- `fasce_eta` — buckets: `0_14`, `15_64`, `65_piu`, `85_piu`, ognuno con `n` e `pct`
- `eta_media`
- `indice_vecchiaia` — pop65+/pop0-14 × 100
- `indice_dipendenza` — (pop0-14 + pop65+) / pop15-64 × 100
- `piramide` — array di 101 voci (età 0–100), ognuna con `eta`, `m`, `f`, `tot`

## `profilo`

Fonte: ISTAT Censimento permanente.

- `istruzione` — livelli istruzione fascia 25–64: `terziario_pct`, `diploma_oltre_pct`, `max_media_pct`, dettaglio per titolo (`nessun_titolo`, `elementare`, `media`, `diploma`, `laurea_triennale`, `laurea_magistrale_dottorato`)
- `lavoro` — `tasso_occupazione`, `tasso_disoccupazione`, `tasso_attivita` con conteggi assoluti
- `famiglie` — `n_famiglie`, `dim_media_famiglia`
- `mobilita` — pendolarismo. **Ferma al 2019** con `_warning`. Chiavi: `pendolari_totale_n`, `fuori_comune_n`, `fuori_comune_pct`, `per_lavoro_n`, `per_studio_n`
- `cittadinanza` — `italiani_n`, `stranieri_n`, `stranieri_pct`

## `turismo`

Due sotto-sezioni a scopo geografico diverso:

- `capacita_comune` — capacità ricettiva comunale. Chiavi: `totale_strutture`, `totale_letti`, `totale_camere`, `indice_turisticita_per_100ab`. Breakdown in `alberghi` (per stelle 1–5 + residence) ed `extra_alberghiero` (bnb, case in affitto, camping, agriturismi, ostelli, case per ferie, rifugi montagna).
- `flussi_provincia` — arrivi e presenze, **solo provinciale (NUTS3)**, con `_warning`. Chiavi: `arrivi_totali`, `arrivi_italiani`, `arrivi_stranieri`, `presenze_totali`, `presenze_italiane`, `presenze_straniere`, `permanenza_media`, `stranieri_pct`.

## `pnrr`

Fonte: Italia Domani / Sistema ReGiS. Solo progetti dove il comune è Soggetto Attuatore.

- `kpi` — `n_progetti`, `totale_finanziamento_pnrr`, `totale_finanziamento_globale`, conteggi per stato (`n_concluso`, `n_in_corso`, `n_altro`), `n_missioni_distinte`, `missioni_principali`
- `per_missione` — aggregato per missione (M1–M7) con descrizione e totali
- `progetti` — array. Ogni progetto: `cup`, `titolo`, `missione`, `componente`, `submisura`, `submisura_descrizione`, `finanziamento_pnrr`, `finanziamento_totale`, `stato_avanzamento` (Concluso / In Corso), `fase_iter`, date (prevista / effettiva), `soggetto_attuatore`, `settore`, `natura`
- `data_estrazione` — ultimo refresh

## `territorio`

Fonti: ISPRA SNPA (suolo), ISPRA IdroGEO (rischio), ISPRA Catasto Rifiuti.

- `kpi` — headline: `ar_kmq`, `suolo_consumato_2024_pct`, `incremento_2024_ha`, `popolazione_frane_p3p4_pct`, `rd_pct_ultimo_anno`, `kg_per_abitante_ultimo_anno`
- `suolo`
  - `stock_2024` — `ha` e `pct`
  - `serie_storica` — array di intervalli (2006-2012, 2012-2015, ..., 2023-2024) con `netto_ha` e `ripristino_ha`
- `rischio_idrogeologico`
  - `alluvioni` — per classe pericolosità (P1, P2, P3): area kmq e pct, popolazione esposta, famiglie, edifici, imprese, beni culturali
  - `frane` — stessa struttura, più P4 e AA (Aree di Attenzione); aggregato `p3p4`
  - `_demografia_idrogeo` — denominatori (popolazione 2011 e 2021, famiglie, edifici, imprese)
- `rifiuti`
  - `ultimo_anno` — anno più recente + KPI (`popolazione`, `ru_t`, `rd_t`, `rd_pct`, `kg_ab`)
  - `serie_storica` — array annuale dal ~2018
  - `_aggregato`, `_aggregato_ruolo` — per comuni in Unioni con gestione rifiuti consolidata
- `geo` — `ar_kmq`, `osmid`, `extent` (bounding box)

## `opere`

Fonte: BDAP MOP. Vista sintetica.

- `_filter` — tipicamente `"only_2025"` (attivi + chiusi anno corrente)
- `n_progetti`
- `progetti` — array. Ogni progetto: `cup`, `descrizione`, `stato` (ATTIVO / CHIUSO), `settore`, `sottosettore`, `natura`, `data_inizio`, `data_fine` (`9999-12-31` = open-ended), `costo_eff`, `costo_prev`, e finanziamenti (`fin_statali`, `fin_europei`, `fin_enti_terr`, `fin_privati`, `fin_altri`)

Per vista aggregata per stato/settore → `bdap_kpi`. Per dettaglio completo filtrabile → tool `comune_opere_dettaglio`.

## `siope`

Fonte: BDAP CKAN bulk — SIOPE movimenti cumulati mensili di Spesa. **Multi-anno** (v0.2.0).

- `_etl_version`, `_source`, `_generated_at`
- `anni_disponibili` — array degli anni con dati (es. `[2025, 2026]`)
- `anno_default` — anno suggerito per visualizzazione (tipicamente l'ultimo completo)
- `per_anno` — dict keyed by year (stringa). Ogni anno:
  - `_resource_id` — UUID risorsa BDAP
  - `anno`, `parziale` (boolean — true se l'anno non è completo)
  - `ente_siope`, `popolazione`
  - `mesi_disponibili` — array tipo `["2025/01", "2025/02", ..., "2025/12"]`
  - `ultimo_mese`, `n_voci`, `totale_anno`
  - `voci` — array di entries. Ogni voce: `codice_gestionale`, `desc_gestionale`, `codice_titolo`, `desc_titolo`, `importo_cumulato`, `ultimo_mese`, `mensili` (dict mensile cumulativo)

Categorie di spesa (codice_titolo):
- `U1...` — Spese correnti
- `U2...` — Spese in conto capitale
- `U7...` — Uscite per conto terzi e partite di giro

## `scuole`

Fonte: MIUR DS0400SCUANAGRAFESTAT + DS0420SCUANAAUTSTAT.

- `anno_scolastico`, `data_estrazione`
- `kpi` — `n_scuole`, `n_sedi_direttivo`, `per_ordine` (infanzia / primaria / sec1 / sec2 / altro)
- `scuole` — array. Ogni scuola: `codice_scuola`, `codice_istituto_riferimento`, `denominazione`, `denominazione_istituto`, `indirizzo`, `cap`, `tipologia`, `macro_ordine`, `caratteristica`, `sede_direttivo`, `sede_scolastica`, `email`, `pec`, `sito_web`

## `aria`

Fonte: ISPRA SNPA. Disponibile per ~604 comuni con stazioni. **Spesso `null`** — controllare sempre prima.

Quando presente: dati monitoraggio PM10, PM2.5, NO2 con lista stazioni e misure.

## `veicoli` — nota: gli incidenti stanno qui

Fonte: ISTAT 41_993 (parco PRA) + ISTAT 41_983 (incidenti) + ACI LOD (iscrizioni).

Top-level: `_anno_dati_parco`, `_anno_dati_incidenti`, `_anno_dati_iscrizioni`, `istat_code`, `denominazione`, `popolazione`.

Tre sotto-sezioni:

- `parco_veicoli`
  - Conteggi per categoria: `autovetture`, `autobus`, `motocicli`, `motocarri`, `altri`, `autocarri`, `motrici`, `rimorchi`
  - `euro` — conteggi per classe Euro (`euro_0` ... `euro_6`) + `pct_inquinanti` (% Euro 0–3)
  - `totale`, `anno`, `tasso_motorizzazione_per_1000_ab`

- `incidenti` — **qui vivono gli incidenti, non al top level**
  - `ultimo_anno` — `anno`, `incidenti`, `morti`, `feriti`, `morti_per_10k_ab`, `feriti_per_10k_ab`
  - `serie_storica` — `anni` array + array paralleli `incidenti`, `morti`, `feriti` (tipicamente 2020–2024)

- `iscrizioni` — nuove immatricolazioni
  - `ultimo_anno` — `totale`, `benzina`, `gasolio`, `elettriche`, `ibride`, `gas_metano_gpl`, `pct_elettriche_ibride`
  - `serie_storica` — `anni` + array paralleli (`totale`, `elettriche`, `ibride`, `elettriche_ibride`)

## `redditi`

Fonte: MEF Dipartimento delle Finanze — dichiarazioni IRPEF su base comunale. Licenza: CC BY 3.0.

- `istat_comune`, `comune`, `sigla_provincia`, `regione`, `cod_catastale`
- `anni_disponibili` — tipicamente `[2020, 2021, 2022, 2023, 2024]`
- `anni` — dict keyed by year. Ogni anno:
  - `contribuenti`
  - `reddito_complessivo` — `freq`, `tot`, `medio`, `medio_per_dichiarante`, `derivato_da_fasce` (boolean — true se medio computato da bucket, non grezzo)
  - `imposta_netta` — `freq`, `tot`, `medio`
  - `addizionale_comunale`, `addizionale_regionale` — stessa forma
  - `trattamento` — bonus IRPEF (2023–2024); per 2020–2022 il bonus è in chiave `bonus` (schema legacy)
  - `tipologie` — breakdown per fonte: `dipendente`, `pensione`, `autonomo`, `fabbricati`, ognuna con `freq`, `tot`, `medio`
  - `fasce` — 8 fasce di reddito f0–f7 (`≤ 0`, `0 - 10k`, `10k - 15k`, `15k - 26k`, `26k - 55k`, `55k - 75k`, `75k - 120k`, `> 120k`), ognuna con `label`, `freq`, `tot`
- `trend` — array convenience: per anno `[anno, reddito_medio, contribuenti, imposta_media, add_comunale_media]`
- `fonte`, `licenza`, `url_fonte`, `last_update`

## `immobili_pa` *(NEW v1.0)*

Fonte: MEF Dipartimento Economia — Censimento Beni Immobili Pubblici al 31/12/2022. Licenza: CC BY 4.0.

**Caveat**: snapshot statico 2022. Su comuni piccoli senza beni dichiarati può essere `null`.

- `_etl_version`, `_source` (`"MEF DE - Beni Immobili Pubblici 2022"`), `_generated_at`
- `anno_rilevazione` — `2022`
- `kpi`
  - `n_totale` — totale immobili dichiarati
  - `n_fabbricati`, `n_terreni`
  - `pct_geo_referenziati` — % immobili con coordinate
  - `pct_vincolo_qualsiasi` — % con vincolo qualsiasi (paesaggistico, culturale, altro)
  - `pct_vincolo_culturale` — % con vincolo culturale stretto
  - `pct_uso_terzi` — % concessi in uso a terzi
  - `superficie_totale_mq`
  - `mix_categoria` — dict keyed da 17 categorie semantiche con conteggi. Categorie possibili: `fabbricati_sociali_scolastici`, `fabbricati_sociali_sanitari`, `fabbricati_sociali_sportivi`, `fabbricati_sociali_culturali`, `fabbricati_amministrativi_uffici`, `fabbricati_amministrativi_sicurezza`, `fabbricati_residenziali`, `fabbricati_pertinenze`, `fabbricati_magazzini`, `fabbricati_parcheggi`, `fabbricati_produttivi`, `terreni_agricoli`, `terreni_boschivi`, `terreni_pascolo`, `terreni_urbani`, `terreni_parchi_pubblici`, `altro`
  - `mix_natura` — dict `{FABBRICATO: n, TERRENO: n}`
- `punti` — array (cappato ~500 con sampling stratificato per categoria). Ogni punto: `lat`, `lon`, `cat` (categoria semantica), `tipo` (tipologia testuale es. "Abitazione"), `sup` (superficie mq, può essere `None`), `vincolo` (bool, true se ≠ "Nessuno"), `uso_terzi` (bool)

I KPI sono calcolati sul totale; i `punti` sono un sample geografico per la mappa.

## `anncsu` *(NEW v1.0)*

Fonte: ANNCSU — Archivio Nazionale Numeri Civici e Strade Urbane (Agenzia delle Entrate + ISTAT). Open Data UE 2023/138 HVD.

**Sample 1000 punti** in dashboard. Per dataset completo (Lecce 47.917, Roma 515.815 civici) usare l'endpoint REST `/data/anncsu_full/<istat>.json` — vedi sezione "Endpoint HTTP diretti" in `SKILL.md`.

- `_etl_version`, `_source` (`"ANNCSU - Agenzia delle Entrate + Istat"`), `_snapshot_date`, `_generated_at`
- `kpi`
  - `n_strade` — totale odonimi distinti
  - `n_civici`, `n_civici_geo_ref`, `pct_geo_ref`
  - `n_civici_metrici` — civici con numerazione metrica (rari)
  - `n_civici_bis` — civici con esponente (es. "23/A", "23 bis")
  - `bbox` — `{lat_min, lat_max, lon_min, lon_max}`
  - `metodi_georef` — dict conteggi per metodo (`gps`, `cartografia`, `catasto`, `ortofoto`, `altro`)
  - `top_10_strade` — array `{odo, acc}` (strade con più accessi numerati)
- `punti` — array 1000 sample. Ogni punto: `lat`, `lon`, `odo` (odonimo UPPERCASE), `civ` (numero civico stringa), `esp` (esponente/subcivico, es. "A"), `quota` (può essere `None`), `met` (metodo georef: 1=GPS, 3=catasto, 4=altra sorgente, 5=…)

**Nota**: gli odonimi sono in maiuscolo e normalizzati (i numerali romani diventano parole: "Via Vittorio Emanuele II" → `VIA VITTORIO EMANUELE SECONDO`). Per lookup di indirizzo usa l'endpoint full e filtra case-insensitive su `odo` + match esatto su `civ`.

## `anac`

Fonte: ANAC contratti pubblici (CC BY 4.0).

- `buyer_name` — nome comune come appare in ANAC
- `count` — numero aggiudicazioni
- `importo_totale` — importo cumulato aggiudicato
- `first_award_date`, `last_award_date` — range temporale
- `distinct_cpv` — n. CPV distinti
- `top_cpv` — array top categorie: `code`, `desc`, `count`, `importo`

Aggregato. Non c'è ancora dettaglio CIG-level via connettore (`comune_contratti` è stub).

## `bdap_kpi`

KPI aggregati sul dataset BDAP-MOP.

- `nome_titolare`
- `totale` — `count`, `costo_lavori_eff`, breakdown finanziamenti
- `per_stato` — split per `ATTIVO` e `CHIUSO`, stessi campi
- `top_settori` — array: `settore`, `count`, `costo`

Settori tipici: INFRASTRUTTURE AMBIENTALI E RISORSE IDRICHE, INFRASTRUTTURE DI TRASPORTO, INFRASTRUTTURE SOCIALI, INFRASTRUTTURE DEL SETTORE ENERGETICO, ALTRE INFRASTRUTTURE PUBBLICHE.
