---
name: cruscotto-italia-workflow
version: 1.0.0
description: How to use the Cruscotto Italia MCP connector efficiently to query Italian municipality data (anagrafica, demografia, censimento, incidenti, parco veicoli, opere pubbliche, PNRR, redditi e fisco, contratti ANAC, scuole MIUR, qualità aria ISPRA, rifiuti, suolo, rischio idrogeologico, patrimonio immobiliare PA, civici e strade ANNCSU). Use this skill whenever the user asks about one or more specific Italian comuni by name (e.g., "dati di Milano", "confronto Lecce vs Bari", "incidenti a Oria", "coordinate di via X numero Y a Lecce"), or mentions Cruscotto Italia, ISTAT 6-digit codes, BDAP, SIOPE, BDAP-MOP, ISPRA SNPA, IdroGEO, ACI LOD, MEF Federalismo Fiscale, MEF Patrimonio Immobiliare PA, ANNCSU (Archivio Nazionale Numeri Civici e Strade Urbane), o qualsiasi combinazione di queste fonti. Trigger this skill anche quando l'utente non nomina esplicitamente il connettore — se la richiesta riguarda dati di un comune italiano coperti dalla dashboard, va usata. Copre: name resolution (omonimi, comuni soppressi/fusi, varianti dialettali), shape JSON di `comune_dashboard` con tutte e 17 le sezioni, workflow multi-comune, endpoint HTTP diretti non-MCP per dataset full (civici ANNCSU), e i caveat per sezione (turismo NUTS3, mobilità 2019, `comune_contratti` stub, aria sparsa, PNRR solo Soggetto Attuatore).
---

# Cruscotto Italia workflow

Reference + workflow patterns for the Cruscotto Italia MCP connector.

- **Server**: `cruscotto-italia-mcp.piersoftckan.biz` (Cloudflare Worker)
- **MCP version corrente**: **0.5.0**
- **Datasets integrati**: **14** (anagrafica, demografia, censimento profilo, turismo, PNRR, territorio ISPRA, opere BDAP-MOP, SIOPE multi-anno, scuole MIUR, aria ISPRA SNPA, parco veicoli ISTAT, incidenti ISTAT, iscrizioni ACI, redditi MEF, patrimonio immobili PA MEF DE, civici ANNCSU)
- **Istituzioni fonte**: **10** (ANAC, BDAP, Italia Domani, ISTAT, ISPRA, MIUR, ACI, MEF Dipartimento Finanze, MEF Dipartimento Economia, Agenzia Entrate)
- **Comuni coperti**: ~7.918

Il connettore espone **10 tool MCP**, ma `comune_dashboard` è il workhorse — restituisce in una sola chiamata la maggior parte dei dati che servono.

## Tool inventory (10 tool MCP)

I tool sono **deferred**: vanno caricati con `tool_search` prima di invocarli.

| Tool | Scopo | Input richiesto |
|---|---|---|
| `search_comune` | Nome → codice ISTAT 6-digit | `query` (string) |
| `comune_dashboard` | Vista completa in una chiamata (17 sezioni: anagrafica, demografia, profilo, turismo, pnrr, territorio, opere, siope, scuole, aria, veicoli, redditi, **immobili_pa**, **anncsu**, anac, bdap_kpi + metadati) | `istat_code` OR `denominazione` |
| `comune_demografia` | Solo demografia ISTAT POSAS (al 1 gennaio anno corrente) | `istat_code` |
| `comune_profilo` | Censimento permanente: istruzione, lavoro, famiglie, mobilità, cittadinanza | `istat_code` |
| `comune_territorio` | ISPRA: consumo di suolo + IdroGEO + rifiuti | `istat_code` |
| `comune_turismo` | Capacità ricettiva (comune) + flussi (provincia) | `istat_code` |
| `comune_pnrr` | Progetti PNRR con il comune Soggetto Attuatore | `istat_code` |
| `comune_opere_dettaglio` | Dettaglio completo opere pubbliche BDAP-MOP filtrate al 2025 (attivi o iniziati dal 2025-01-01) | `istat_code` |
| `comune_contratti` | **STUB in v0.2** — ritorna sempre `{results: [], _stub: true}`. NON usare; per dati ANAC usa la sezione `anac` di `comune_dashboard` (count, importo, top_cpv, range date) | `istat_code` + filtri opzionali |
| `mcp_info` | Metadati server, freshness per source, manifest ETL | — |

**Regola pratica**: preferisci `comune_dashboard` salvo che la richiesta sia molto stretta (es. "solo la popolazione"). Costo simile, evita un secondo round-trip per le follow-up.

## Endpoint HTTP diretti (non-MCP)

Lo stesso Worker espone alcuni endpoint REST pass-through R2 per dataset troppo grandi da serializzare in MCP tool result.

### `GET /data/anncsu_full/<istat>.json`

Snapshot completo dei civici ANNCSU per un comune (l'intero set, non i 1000 punti sample della dashboard).

- **Host**: `https://cruscotto-italia-mcp.piersoftckan.biz`
- **Cache**: 24h, CORS `*`, no auth
- **Copertura**: ~5.387 comuni (sottoinsieme di quelli con `pct_geo_ref` significativa)
- **Dimensioni tipiche**: Lecce ~4.7 MB / 47.917 civici; Roma ~50 MB / 515.815 civici (gzip ~4 MB); piccoli comuni qualche centinaio di KB
- **Shape**: identica a `dashboard.anncsu` ma con `punti[]` esteso e `_full: true`. Ogni punto: `{lat, lon, odo, civ, esp, quota, met}` dove `odo` = odonimo uppercase, `civ` = numero civico stringa, `esp` = subcivico/esponente lettera (es. "A", "B"), `met` = metodo georef (1=GPS, 3=catasto, 4=altra sorgente, 5=…)

**Quando usarlo**: richieste puntuali su strade/civici specifici (coordinate di un indirizzo, conteggio civici per via, ricerca odonimi). La sezione `anncsu` della dashboard ha solo 1000 punti sample che bastano per la mappa generale ma non per lookup di indirizzo.

**Pattern operativo "civico puntuale"** (es. "coordinate di via X numero Y a Z"):

1. `search_comune(query="Z")` → istat
2. HTTP GET `https://cruscotto-italia-mcp.piersoftckan.biz/data/anncsu_full/<istat>.json`
3. Filtra `punti` con `odo` contenente l'uppercase della via E `civ == "<numero>"`
4. Ritorna lat, lon, eventuale `esp`, `met`

Attenzione: gli odonimi sono UPPERCASE; "II", "III" vengono normalizzati a "SECONDO", "TERZO" (es. "Via Vittorio Emanuele II" è memorizzata come `VIA VITTORIO EMANUELE SECONDO`).

## Step 1 — Risolvere il nome del comune

L'utente dà un nome, i tool vogliono un codice ISTAT. Sempre `search_comune` prima, salvo che l'utente fornisca già il codice.

```
search_comune(query="Lecce") → istat_code "075035"
```

Tre cose da gestire:

**Omonimie.** Italia ha molti casi di nomi identici o quasi: "San Teodoro" (Sardegna e Sicilia), "Castel San Pietro" (Romagna e altrove), "Borgo San Lorenzo" vs "Borgo San Martino", ecc. `search_comune` ritorna i candidati ranked con `provincia` e `regione`: mostra la lista all'utente e chiedi quale, non tirare a indovinare. Se l'utente ha già specificato la provincia ("Oria (BR)", "Castelnuovo in provincia di Modena"), scegli direttamente.

**Comuni soppressi (fusioni/rinomine dal 2014 in poi).** Esempio: Pozza di Fassa, accorpata in San Giovanni di Fassa-Sèn Jan il 1 gennaio 2018. `search_comune` ritorna zero match. Fallback in ordine:

1. Cerca un **frammento distintivo** del nome ("Fassa" invece di "Pozza di Fassa", "Saluggia" invece di "Borgo d'Ale Saluggia")
2. Cerca **provincia + substring** se conosci l'area
3. Come ultima opzione, `web_search` per "fusione comune <nome>" e poi `search_comune` sul successore

Quando trovi il successore, esplicita all'utente: "Pozza di Fassa è stata fusa in San Giovanni di Fassa-Sèn Jan il 1 gennaio 2018; i dati per il territorio originale sono ora aggregati sotto il successore (ISTAT 022250)." Questo caveat conta per ogni serie storica.

**Errori di battitura e varianti dialettali.** `search_comune` è tollerante ma non infallibile. Su zero match con nome sospetto, prova varianti: con/senza apostrofi, vocali accentate, grafie alternative comuni (Cefalù/Cefalu, Forlì/Forli, Sant'Antonio/Santantonio).

## Step 2 — Pull della dashboard

```
comune_dashboard(istat_code="075035")
```

Risposta JSON corposa. Spesso viene paginata come file: in quel caso usa `bash`/grep/python per estrarre sezioni specifiche, evita di dumpare tutto. Vedi `references/dashboard_schema.md` per il key map completo — caricala la prima volta che lavori con la dashboard in una sessione, poi tienila a mente.

**Top-level keys (ordine reale)**:

- `_etl_version`, `_generated_at`, `_missing` — metadati
- `anagrafica` — identità, codice IPA, codice fiscale, KPI headline
- `demografia` — popolazione, piramide età, indici
- `profilo` — istruzione, lavoro, famiglie, mobilità, cittadinanza
- `turismo` — capacità ricettiva (comune) + flussi (provincia NUTS3)
- `pnrr` — progetti PNRR con comune Soggetto Attuatore
- `territorio` — suolo + rischio idrogeologico + rifiuti
- `opere` — opere pubbliche BDAP-MOP
- `siope` — spese **multi-anno** con `per_anno` keyed e `anno_default`
- `scuole` — anagrafe MIUR
- `aria` — qualità aria ISPRA SNPA (~604 comuni; spesso `null`)
- `veicoli` — **`veicoli.incidenti` qui dentro, non al top level**. Anche parco PRA e iscrizioni.
- `redditi` — dichiarazioni IRPEF MEF (tipicamente 2020–2024)
- `immobili_pa` — **NEW** patrimonio immobiliare PA MEF DE 2022 (KPI + fino a 500 punti georeferenziati)
- `anncsu` — **NEW** civici e strade Agenzia Entrate + ISTAT (KPI + 1000 punti sample; full via endpoint REST)
- `anac` — aggregato contratti pubblici
- `bdap_kpi` — KPI BDAP-MOP per stato/settore

## Step 3 — Estrai quello che ha chiesto l'utente

Map intent → sottosezione:

- "incidenti", "morti", "feriti", "sinistri" → `veicoli.incidenti`
- "auto", "parco veicoli", "Euro 6", "tasso motorizzazione" → `veicoli.parco_veicoli`
- "nuove immatricolazioni", "elettriche", "ibride" → `veicoli.iscrizioni`
- "rifiuti", "raccolta differenziata" → `territorio.rifiuti`
- "frane", "alluvioni", "rischio idrogeologico" → `territorio.rischio_idrogeologico`
- "consumo di suolo" → `territorio.suolo`
- "PM10", "PM2.5", "qualità dell'aria" → `aria` (controlla `null` prima)
- "redditi", "IRPEF", "addizionale comunale" → `redditi`
- "scuole", "istituti" → `scuole`
- "opere pubbliche", "lavori pubblici", "cantieri", "BDAP" → `opere` o `bdap_kpi` (per dettaglio filtrato 2025 → `comune_opere_dettaglio` tool)
- "PNRR", "Italia Domani", "ReGiS" → `pnrr`
- "appalti", "gare", "ANAC", "CIG" → `anac` aggregato (NOT `comune_contratti`)
- "spese", "SIOPE", "bilancio" → `siope.per_anno[<anno>]`
- "turismo", "alberghi", "stelle" → `turismo.capacita_comune`
- "arrivi", "presenze", "permanenza media" → `turismo.flussi_provincia` (con caveat NUTS3)
- "patrimonio", "immobili pubblici", "beni immobili", "fabbricati PA", "demanio" → `immobili_pa`
- "civico", "via", "strada", "odonimo", "coordinate di indirizzo" → `anncsu` (KPI/sample) o endpoint `/data/anncsu_full/<istat>.json` (lookup puntuale)

Se la sezione è `null` o in `_missing`, dillo esplicitamente. Non inventare.

## Multi-comune workflow

Confronto fra due o più comuni:

1. Risolvi tutti gli ISTAT in parallelo via `search_comune` (uno per nome)
2. Conferma omonimie con l'utente prima di procedere
3. `comune_dashboard` per ognuno (le chiamate possono andare in parallelo)
4. Estrai la stessa sotto-sezione da ogni risposta
5. Presenta il confronto

Su comuni con popolazione molto diversa (es. 14k vs 4k), preferisci metriche **per-capita** o **per-10k-ab** — di solito già presenti (`morti_per_10k_ab`, `feriti_per_10k_ab`, `tasso_motorizzazione_per_1000_ab`, `rd_pct`). Conteggi grezzi soli fuorviano.

Se almeno uno dei comuni nel confronto è il risultato di una fusione recente, nota quali anni sono pre/post-fusione: la serie storica può concatenare due ambiti territoriali diversi.

## Data freshness — cosa dire all'utente

Ogni sezione ha la sua cadenza. Esponi `_anno_dati_*`, `anno`, `_snapshot_date` o `data_estrazione` quando citi numeri, specie su dati ad alta frequenza.

| Sezione | Cadenza | Lag tipico |
|---|---|---|
| `demografia` (POSAS) | Annuale (rif. 1 gen) | ~3 mesi |
| `veicoli.parco_veicoli` (ISTAT 41_993) | Annuale | rilascio dicembre per anno precedente |
| `veicoli.incidenti` (ISTAT 41_983) | Annuale | rilascio luglio per anno precedente |
| `veicoli.iscrizioni` (ACI LOD) | Annuale | rilascio gennaio |
| `territorio.suolo` (ISPRA SNPA) | Annuale | metà anno (Rapporto SNPA) |
| `territorio.rifiuti` (Catasto ISPRA) | Annuale | metà anno |
| `redditi` (MEF Dip. Finanze) | Annuale | ~5–6 mesi dopo anno fiscale |
| `pnrr` (Italia Domani / ReGiS) | Snapshot periodici | vedi `data_estrazione` |
| `siope` (BDAP CKAN) | Mensile cumulativo, multi-anno | anno corrente parziale (vedi `parziale: true`) |
| `anac` | Periodico | controlla `last_award_date` |
| `aria` (ISPRA SNPA) | Live dove disponibile | controlla `_generated_at` |
| `immobili_pa` (MEF DE) | Snapshot statico al 31/12/2022 | `anno_rilevazione: 2022` |
| `anncsu` (Agenzia Entrate + ISTAT) | Mensile | vedi `_snapshot_date` |

Per freshness completa chiama `mcp_info`.

## Caveat conosciuti (sempre da segnalare quando rilevante)

- **`comune_contratti` è uno stub.** Per i contratti usa `anac` aggregato della dashboard. La query CIG-level con filtri per anno, importo, fornitore, RUP, CPV è prevista ma non ancora attiva.
- **I flussi turistici sono NUTS3 (provinciali), non comunali.** ISTAT non pubblica arrivi/presenze per singolo comune. La dashboard espone i flussi provinciali con un `_warning` field: passa quel warning verbatim, non spacciare i numeri come comunali.
- **Mobilità ferma al 2019.** `profilo.mobilita` mostra pendolarismo dall'ultima onda del censimento permanente disponibile (2019). La dashboard segnala con `_warning` — non presentarli come attuali.
- **La sezione PNRR copre solo progetti dove il comune è Soggetto Attuatore.** Progetti realizzati sul territorio da altri enti (Regioni, Ministeri, GSE, ASL, università) NON sono inclusi — il dataset upstream non ha mapping affidabile progetto↔territorio. Dichiaralo esplicitamente quando rispondi a "quanti soldi PNRR arrivano a <comune>".
- **Qualità dell'aria sparsa.** Solo ~604 comuni su ~7900 hanno stazioni. Se `aria` è `null`, dì "nessuna stazione ISPRA SNPA in questo comune", non inventare.
- **ANNCSU: 1000 punti sample nella dashboard, full via endpoint REST.** Per query puntuali su civici/indirizzi usa `/data/anncsu_full/<istat>.json` (vedi sezione "Endpoint HTTP diretti").
- **`immobili_pa` con sampling stratificato.** I `punti` sono cappati a ~500 con sampling stratificato per categoria (su Roma/Milano la copertura è qualitativamente rappresentativa, non esaustiva). I KPI invece sono calcolati sul totale degli immobili dichiarati. Per piccoli comuni senza immobili PA dichiarati, `immobili_pa` può essere `null`.
- **ANAC `_period_files` (TODO upstream)**: la finestra temporale dei contratti non è ancora propagata al dashboard. Per il periodo esatto controlla `first_award_date` e `last_award_date` nella sezione `anac`.
- **Comuni bilingui / fusi (ACI)**: per le iscrizioni veicolari ACI le anomalie sono note solo per Bolzano, Trento, Aosta (immatricolazioni cross-border); il dataset gestisce 32 casi speciali (bilingui + fusioni) per chiudere il match.

## File di riferimento

- `references/dashboard_schema.md` — Key map completo della response `comune_dashboard`, con significato dei campi e unità tipiche. Caricala la prima volta che lavori con la struttura dashboard in una sessione.

## Changelog

- **v1.0 (2026-05-13)**: allineamento con MCP server v0.5.0. Aggiunto `comune_opere_dettaglio` al tool inventory. Aggiunta sezione "Endpoint HTTP diretti (non-MCP)" con `/data/anncsu_full/<istat>.json`. Aggiunte sezioni dashboard `immobili_pa` e `anncsu`. Aggiornato `siope` multi-anno (`per_anno`, `anno_default`). Aggiornato dataset count (14) e institutions count (10). Pattern operativo "civico puntuale" aggiunto.
- **v0.1**: versione iniziale (10 tool, schema base, 12 dataset).
