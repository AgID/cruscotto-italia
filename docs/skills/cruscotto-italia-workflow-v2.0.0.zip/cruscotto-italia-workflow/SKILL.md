---
name: cruscotto-italia-workflow
version: 2.0.0
description: Cruscotto Italia MCP connector (7918 comuni). Tool: comune_kpi (~55 KPI ~620 token: query puntuali/confronti); comune_dashboard (25 sezioni con array, mappe); search_comune (nome→ISTAT); comune_opere_dettaglio; anncsu_civico_search. Sezioni: anagrafica, demografia POSAS, censimento profilo annuale, turismo, PNRR, ISPRA suolo/idro/rifiuti/aria, BDAP-MOP opere, SIOPE, ANAC, MIUR scuole, ACI veicoli/incidenti, MEF redditi IRPEF, MEF DE patrimonio PA, ANNCSU civici, MdS farmacie/ospedali, GSE PUN ricarica EV, AGCOM FTTH, MIMIT carburanti, RUNTS, ISTAT ASIA UL imprese addetti ATECO, ISTAT pendolarismo lavoro 2021, ISTAT Basi Territoriali 2021 con 119 variabili per sezione di censimento (eta/sesso, titolo studio, occupati, stranieri UE/extra-UE, famiglie, abitazioni). Trigger: ISTAT, BDAP, SIOPE, ISPRA, PNRR, ANAC, MEF, ANNCSU, AGCOM, MIMIT, RUNTS, ODV APS ETS 5x1000, FTTH, carburanti, ASIA imprese ATECO, pendolarismo, sezioni di censimento, densita popolazione, indice vecchiaia.
---

# Cruscotto Italia workflow

Reference + workflow patterns for the Cruscotto Italia MCP connector.

- **Server**: `cruscotto-italia-mcp.dati.gov.it` (Cloudflare Worker)
- **Datasets integrati**: **24** (anagrafica, demografia, censimento profilo annuale, turismo, PNRR, territorio ISPRA, opere BDAP-MOP, SIOPE multi-anno, scuole MIUR, aria ISPRA SNPA, parco veicoli ISTAT, incidenti ISTAT, iscrizioni ACI, redditi MEF, patrimonio immobili PA MEF DE, civici ANNCSU, sanità territoriale Ministero Salute, punti di ricarica EVSE PUN GSE/MASE, banda larga AGCOM BBmap, distributori carburanti MIMIT, enti Terzo Settore RUNTS Min. Lavoro, imprese e addetti ISTAT ASIA UL, matrice pendolarismo lavoro 2021 Censimento permanente, **Basi Territoriali 2021 e Variabili censuarie con 119 variabili per sezione di censimento**)
- **Istituzioni fonte**: **15** (ANAC, BDAP, Italia Domani, ISTAT, ISPRA, MIUR, ACI, MEF Dipartimento Finanze, MEF Dipartimento Economia, Agenzia Entrate, Ministero della Salute, GSE / MASE, AGCOM, MIMIT, Ministero del Lavoro e Politiche Sociali)
- **Comuni coperti**: ~7.918

Il connettore espone **6 tool MCP**. La scelta del tool giusto dipende dalla query:

- **Query puntuali e confronti tra comuni** → `comune_kpi` (~620 token, leggero)
- **Vista dettagliata singolo comune** → `comune_dashboard` (~250K token, completo)
- Risoluzione nome → `search_comune`
- Dettaglio opere BDAP → `comune_opere_dettaglio`
- Query civici → `anncsu_civico_search`

## Tool inventory (6 tool MCP)

I tool sono **deferred**: vanno caricati con `tool_search` prima di invocarli.

| Tool | Scopo | Quando usarlo | Output size |
|---|---|---|---|
| `mcp_info` | Metadati server, freshness per source | Verifica freshness dataset | piccolo |
| `search_comune` | Nome → codice ISTAT 6-digit | Quando hai solo il nome del comune | piccolo |
| `comune_kpi` | **55 KPI sintetici** in 24 gruppi tematici. Importi anche pro-capite | **PRIMO TOOL** per query puntuali ("popolazione di Bari"), confronti tra N comuni ("Verona vs Bari"), ranking ("top 5 per FTTH") | ~620 token |
| `comune_dashboard` | **Vista completa 25 sezioni** con array dettagliati: top CPV, settori BDAP, missioni PNRR, piramide età, time series SIOPE, mappe punti, top settori ATECO ASIA, sezioni di censimento 2021 | Vista approfondita singolo comune. Solo quando servono i dettagli che `comune_kpi` non ha | ~250K token |
| `comune_opere_dettaglio` | Lista BDAP-MOP filtrata al 2025 (attivi o iniziati dal 2025-01-01) con CUP, costi, finanziamenti, stato | Quando servono i singoli CUP filtrabili | medio |
| `anncsu_civico_search` | Query puntuali su civici con filtri server-side. Filtri: `odonimo` (substring), `civico` (esatto). Default limit 50, max 500 | Verifica esistenza/coordinate di un civico specifico | piccolo |

**Regola pratica decision tree**:

```
User chiede dato singolo comune?
├─ Domanda puntuale o confronto tra comuni? → comune_kpi
├─ Dettaglio (mappe, top liste, time series)? → comune_dashboard
├─ Singoli CUP opere pubbliche? → comune_opere_dettaglio
└─ Civico/strada specifica? → anncsu_civico_search
```

## Schema `comune_kpi` (output ~2.5KB)

Risposta strutturata in 24 gruppi tematici. Ogni gruppo contiene 2-7 campi scalari. Campi mancanti sono `null` espliciti (schema stabile).

```json
{
  "_generated_at": "2026-05-15T08:00:04+00:00",
  "_etl_version": "0.1.0",
  "_missing": [],
  "anagrafica": {"istat", "nome", "provincia_sigla", "regione", "codice_fiscale", "codice_catastale"},
  "demografia": {"popolazione", "maschi", "femmine", "eta_media", "indice_vecchiaia", "indice_dipendenza", "riferimento"},
  "istruzione_profilo": {"anno", "pct_terziario", "pct_diploma_oltre"},
  "lavoro_profilo": {"anno", "tasso_occupazione", "tasso_disoccupazione", "tasso_attivita"},
  "redditi_mef": {"anno_fiscale", "n_contribuenti", "reddito_medio_eur", "imposta_netta_media_eur"},
  "scuole_miur": {"n_scuole", "anno_scolastico", "scuole_per_1000_ab"},
  "contratti_anac": {"n_aggiudicazioni", "importo_totale_eur", "importo_per_abitante_eur", "ultima_aggiudicazione"},
  "opere_bdap": {"n_progetti", "importo_totale_eur", "importo_per_abitante_eur"},
  "pnrr": {"n_progetti", "n_concluso", "n_in_corso", "importo_assegnato_eur", "importo_per_abitante_eur"},
  "siope": {"anno", "totale_uscite_eur", "uscite_per_abitante_eur"},
  "patrimonio_pa": {"n_immobili", "n_fabbricati", "n_terreni", "superficie_totale_mq"},
  "ambiente": {"superficie_kmq", "consumo_suolo_pct", "raccolta_differenziata_pct", "rifiuti_kg_per_abitante"},
  "aria_ispra": {"ha_stazione", "anno", "pm10_media", "pm25_media", "no2_media"},
  "turismo": {"anno", "totale_strutture", "totale_letti", "indice_turisticita_per_100ab"},
  "veicoli_aci": {"anno", "totale_veicoli", "autovetture", "tasso_motorizzazione_per_1000_ab", "pct_inquinanti"},
  "banda_larga_agcom": {"famiglie_residenti", "copertura_ftth_pct", "copertura_ftth_20m_pct", "data_rilevazione"},
  "ricarica_ev_pun": {"n_totale", "n_attivi", "pct_attivi", "potenza_totale_kw", "punti_per_1000_ab"},
  "carburanti_mimit": {"n_impianti", "n_pompe_bianche", "prezzo_medio_benzina_self", "prezzo_medio_gasolio_self", "impianti_per_1000_ab"},
  "civici_anncsu": {"n_strade", "n_civici", "pct_geo_ref", "snapshot_date"},
  "terzo_settore_runts": {"n_enti_totali", "n_5x1000", "pct_5x1000", "enti_per_1000_ab", "snapshot_date"},
  "imprese_asia": {"anno", "ul_totali", "addetti_totali", "addetti_per_ul", "ul_yoy_pct", "ul_per_1000_ab"},
  "sanita_mds": {"n_farmacie", "n_parafarmacie", "n_ospedali", "posti_letto_ospedalieri", "farmacie_per_1000_ab"},
  "censimento": {"n_sezioni", "pop_totale", "famiglie_totali", "abitazioni_totali", "stranieri_totali", "occupati_15_64", "area_kmq", "densita_ab_per_kmq"}
}
```

**Importi finanziari**: sempre in **euro interi**. Versione **pro-capite o per-1000-abitanti** disponibile dove ha senso comparabile (ANAC, BDAP, PNRR, SIOPE, scuole, ricarica EV, carburanti, RUNTS, farmacie, imprese ASIA).

**Trend YoY**: non inclusi in `comune_kpi`, eccetto `imprese_asia.ul_yoy_pct` (variazione UL anno precedente). Per altre serie storiche usa `comune_dashboard.redditi.anni[*]`, `.siope.per_anno[*]`, o `.asia.serie_storica`.

## Workflow patterns

### Pattern 1: query puntuale singolo comune

User: *"Qual è il reddito medio a Lecce?"*

```
1. search_comune("Lecce") → istat="075035"
2. comune_kpi(istat_code="075035") → leggi redditi_mef.reddito_medio_eur
```

### Pattern 2: confronto N comuni

User: *"Compara Verona, Bari e Lecce su PNRR e banda larga"*

```
1. search_comune("Verona") → "023091"
2. search_comune("Bari") → "072006"
3. search_comune("Lecce") → "075035"
4. comune_kpi("023091"), comune_kpi("072006"), comune_kpi("075035")
5. Estrai pnrr.importo_per_abitante_eur e banda_larga_agcom.copertura_ftth_pct
   da ciascuna risposta. Componi tabella.
```

**Vantaggio kpi vs dashboard**: 3 chiamate × ~620 token = ~1.860 token totali invece di ~750.000 con `comune_dashboard`.

### Pattern 3: vista approfondita singolo comune

User: *"Mostrami i top 5 contratti di Bari per importo"*

```
1. search_comune("Bari") → "072006"
2. comune_dashboard(istat_code="072006") → leggi anac.top_cpv per dettaglio
```

Qui serve `comune_dashboard` perché `comune_kpi` non ha array (solo conteggi aggregati).

### Pattern 4: civico specifico

User: *"Quale è la quota altimetrica di Via dei Mille civico 5 a Lecce?"*

```
1. search_comune("Lecce") → "075035"
2. anncsu_civico_search(istat_code="075035", odonimo="MILLE", civico="5")
```

### Pattern 5: opere pubbliche dettaglio

User: *"Quali sono le opere PNRR in corso a Matera con CUP?"*

```
1. search_comune("Matera") → "077014"
2. comune_opere_dettaglio(istat_code="077014") → filtra per stato="ATTIVO"
```

### Pattern 6: tessuto economico e imprese

User: *"Quanti addetti e in quali settori ha Lecce?"*

```
1. search_comune("Lecce") → "075035"
2. comune_kpi("075035") → leggi imprese_asia.ul_totali, addetti_totali,
   addetti_per_ul (dimensione media UL)
3. Se servono top settori ATECO o classi dimensionali:
   comune_dashboard("075035") → leggi asia.kpi.top_settori_ul,
   asia.kpi.mix_classe_addetti, asia.serie_storica
```

User: *"Confronto tessuto economico Milano vs Bari"*

```
1. comune_kpi("015146"), comune_kpi("072006")
2. Estrai imprese_asia.{ul_totali, addetti_per_ul, ul_per_1000_ab}
   da ciascuna. Componi tabella.
```

### Pattern 7: censimento sezioni 2021 (Basi Territoriali)

User: *"Quante sezioni di censimento ha Lecce? E quanta popolazione?"*

```
1. search_comune("Lecce") → "075035"
2. comune_kpi("075035") → leggi censimento.n_sezioni, censimento.pop_totale,
   censimento.area_kmq, censimento.densita_ab_per_kmq
```

User: *"Dimmi la distribuzione di stranieri UE vs Extra-UE per fascia eta a Lecce"*

```
1. comune_dashboard("075035") → leggi censimento.kpi_comune.stranieri_*
   e censimento.distribuzioni_comune.stranieri_eta (0-29 / 30-54 / 55+).
2. Per il dettaglio puntuale per ogni sezione di censimento (poligoni +
   119 variabili raw P*/IT*/ST*/PF*/A*/E*) usa l'endpoint REST:
   GET https://cruscotto-italia.dati.gov.it/data/censimento_full/075035.geojson
   (FeatureCollection EPSG:4326 WGS84). Lazy fetch: solo se servono dati
   per sezione, non aggregati comunali.
```

User: *"Trova le sezioni di censimento di Roma con piu di 5000 ab/km2 di densita"*

```
1. Lazy fetch /data/censimento_full/058091.geojson (Roma ~13.000 sezioni,
   file ~3 MB gzip). Per ogni feature calcola densita = vars.P1 / (area_mq/1e6).
2. Filtra feature con densita > 5000. Output: lista (sez_id, densita, P1).
```

Indicatori derivati comuni (formule client-side dalle 119 vars raw):

| Indicatore | Formula | Note |
|---|---|---|
| Densità popolazione (ab/km²) | `P1 / (area_mq / 1e6)` | richiede area_mq > 0 |
| % over 65 | `(P27+P28+P29) / P1 * 100` | P1 = pop totale |
| % under 15 | `(P14+P15+P16) / P1 * 100` | |
| % stranieri | `ST1 / P1 * 100` | |
| % laureati su pop 9+ | `P90 / P83 * 100` | P83 = denominatore |
| Indice di vecchiaia | `(P27+P28+P29) / (P14+P15+P16) * 100` | >100 = più anziani che giovani |
| % famiglie unipersonali | `PF3 / PF1 * 100` | |
| % abitazioni vuote | `A3 / A8 * 100` | |
| % stranieri Extra-UE | `ST19 / ST1 * 100` | sul totale stranieri |
| % donne occupate 15-64 | `P103 / P101 * 100` | sul totale occupati |

## Caveat per sezione

- **anac**: copre solo i comuni che sono *stazioni appaltanti* nel periodo monitorato. Comuni piccoli senza aggiudicazioni → `anac: null` o counter zero. La data `ultima_aggiudicazione` indica la freschezza reale del dato.
- **aria_ispra**: solo 604 comuni hanno stazione di rilevazione. Se `ha_stazione: false`, le medie PM10/PM2.5/NO2 sono null.
- **immobili_pa**: snapshot 2022 (MEF DE Censimento Beni Immobili). Dato non aggiornato annualmente.
- **anncsu**: snapshot Agenzia Entrate. Coverage geografica varia per comune.
- **runts**: include 6 sezioni ETS (ODV/APS/EF/IS/SMS/ETS). `pct_5x1000` indica enti accreditati al 5x1000.
- **pun**: punti di ricarica EV dichiarati al GSE. `pct_attivi` < 100% normale (impianti in collaudo).
- **banda_larga_agcom**: copertura DESI = % famiglie raggiunte da almeno una linea FTTH. `copertura_ftth_20m_pct` = % raggiunte a velocità ≥ 1 Gbps.
- **imprese_asia / .asia**: dati ISTAT ASIA UL. **Latency upstream ~2 anni**: nel 2026 `latest_year=2023` (ISTAT pubblica con Q4 anno succ.). **Caveat conta UL non imprese**: un'impresa con sedi multiple compare in più comuni; il dato è coerente con la logica operativa territoriale (dove sono i lavoratori), non con la logica societaria. Per comuni molto piccoli (UL totali <10) il `ul_yoy_pct` è poco significativo (rumore su numeri piccoli). Serie storica: 2018-2023 (6 anni). ATECO classificazione NACE Rev.2 a 2 cifre (88 divisioni economiche). Classi addetti: W0_9 (micro 1-9), W10_49 (piccole), W50_249 (medie), W_GE250 (grandi). Licenza CC BY 3.0 IT.
- **censimento (Basi Territoriali 2021)**: 756.376 sezioni nazionali, 7904 comuni coperti (100% incluso TN/BZ). **Distinto da `profilo`**: `profilo` è il Censimento permanente *annuale* aggregato comune-level (rilascio 2024); `censimento` è *Basi Territoriali 2021 + Variabili censuarie* — dato strutturalmente decennale a livello di **sezione di censimento** (poligoni georeferenziati) con 119 variabili per sezione. **33% sezioni 'no_vars'**: aree non residenziali (parchi nazionali, zone industriali, infrastrutture, aree militari) non rilevate dal Censimento permanente perché disabitate — è atteso, non bug. Sezione `censimento` nel dashboard contiene solo aggregati comune-level (~3-5 KB); per le 119 variabili raw e le geometrie usa `/data/censimento_full/<istat>.geojson` (30 KB - 3 MB, EPSG:4326). Ultimo rilascio 14/05/2026. Licenza CC BY 3.0 IT.

## Endpoint REST aggiuntivi

Oltre ai tool MCP, il Worker espone:

- `GET /data/anncsu_full/<istat>.json` — dataset completo civici per comune (per Roma 515.815, Milano ~280.000). Usalo solo se serve davvero il dato completo; per query puntuali usa `anncsu_civico_search` che evita di buttare 500k civici nel context LLM.
- `GET /data/censimento_full/<istat>.geojson` — FeatureCollection EPSG:4326 (WGS84) di tutte le sezioni di censimento del comune, con poligoni georeferenziati + 119 variabili demografiche/abitative raw per sezione (P1-P103, IT1-IT12, ST1-ST33, PF1, PF3-PF8, A2/A3/A8, E3). Dimensioni: ~30 KB (Morterone) — ~3 MB (Roma 13.000 sezioni). Usalo solo per query che richiedono il dettaglio per sezione (densità, mappe choropleth, filtri territoriali sub-comunali); per gli aggregati comune-level basta `comune_dashboard.censimento` (~3 KB).

## Codici ISTAT di test consigliati

| Codice | Comune | Note |
|---|---|---|
| 075035 | Lecce | comune medio, ampia copertura dati, ~11.900 UL ASIA |
| 072006 | Bari | capoluogo Puglia |
| 058091 | Roma | metropoli, dati molto ricchi |
| 015146 | Milano | metropoli nord, capoluogo industriale |
| 077014 | Matera | medio sud, patrimonio UNESCO |
| 007021 | Cogne | piccolo comune montano |
| 097055 | Morterone | comune piccolissimo (33 abitanti), test edge case ASIA (3 UL) e censimento (~1-2 sezioni) |
