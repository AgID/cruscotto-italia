---
name: cruscotto-italia-workflow
version: 1.7.0
description: Cruscotto Italia MCP connector (7918 comuni italiani). Tool principali: comune_kpi (~55 KPI sintetici, ~620 token: usa per ricerche puntuali e confronti tra comuni); comune_dashboard (vista completa 22 sezioni: usa per dettaglio singolo comune con array, mappe, time series); search_comune (nome→ISTAT); comune_opere_dettaglio (BDAP filtrato 2025); anncsu_civico_search (query civici). Sezioni: anagrafica, demografia POSAS, censimento profilo, turismo, PNRR Italia Domani, ISPRA suolo/idro/rifiuti/aria, BDAP-MOP opere, SIOPE multi-anno, ANAC contratti, MIUR scuole, ACI veicoli/incidenti, MEF redditi IRPEF 2020-2024, MEF DE patrimonio immobili PA, ANNCSU civici/strade, MdS farmacie/parafarmacie/ospedali, GSE/MASE PUN ricarica EV, AGCOM banda larga FTTH, MIMIT carburanti, RUNTS Terzo Settore. Trigger keywords: ISTAT, BDAP, SIOPE, ISPRA, PNRR, ANAC, MEF, ANNCSU, AGCOM, MIMIT, RUNTS, ODV APS ETS volontariato 5x1000, colonnine, fibra FTTH, distributori carburanti benzina gasolio.
---

# Cruscotto Italia workflow

Reference + workflow patterns for the Cruscotto Italia MCP connector.

- **Server**: `cruscotto-italia-mcp.piersoftckan.biz` (Cloudflare Worker)
- **Datasets integrati**: **19** (anagrafica, demografia, censimento profilo, turismo, PNRR, territorio ISPRA, opere BDAP-MOP, SIOPE multi-anno, scuole MIUR, aria ISPRA SNPA, parco veicoli ISTAT, incidenti ISTAT, iscrizioni ACI, redditi MEF, patrimonio immobili PA MEF DE, civici ANNCSU, sanità territoriale Ministero Salute, punti di ricarica EVSE PUN GSE/MASE, banda larga AGCOM BBmap, distributori carburanti MIMIT, enti Terzo Settore RUNTS Min. Lavoro)
- **Istituzioni fonte**: **15** (ANAC, BDAP, Italia Domani, ISTAT, ISPRA, MIUR, ACI, MEF Dipartimento Finanze, MEF Dipartimento Economia, Agenzia Entrate, Ministero della Salute, GSE / MASE, AGCOM, MIMIT, Ministero del Lavoro e Politiche Sociali)
- **Comuni coperti**: ~7.918

Il connettore espone **6 tool MCP**. La scelta del tool giusto dipende dalla query:

- **Query puntuali e confronti tra comuni** → `comune_kpi` (~620 token, leggero)
- **Vista dettagliata singolo comune** → `comune_dashboard` (~250K token, completo)
- Risoluzione nome → `search_comune`
- Dettaglio opere BDAP → `comune_opere_dettaglio`
- Query civici → `anncsu_civico_search`

## Tool inventory (6 tool MCP)

I tool sono **deferred**: vanno caricati con `tool_search` prima di invocarli.

| Tool | Scopo | Quando usarlo | Output size |
|---|---|---|---|
| `mcp_info` | Metadati server, freshness per source | Verifica freshness dataset | piccolo |
| `search_comune` | Nome → codice ISTAT 6-digit | Quando hai solo il nome del comune | piccolo |
| `comune_kpi` | **55 KPI sintetici** in 22 gruppi tematici. Importi anche pro-capite | **PRIMO TOOL** per query puntuali ("popolazione di Bari"), confronti tra N comuni ("Verona vs Bari"), ranking ("top 5 per FTTH") | ~620 token |
| `comune_dashboard` | **Vista completa 22 sezioni** con array dettagliati: top CPV, settori BDAP, missioni PNRR, piramide età, time series SIOPE, mappe punti | Vista approfondita singolo comune. Solo quando servono i dettagli che `comune_kpi` non ha | ~250K token |
| `comune_opere_dettaglio` | Lista BDAP-MOP filtrata al 2025 (attivi o iniziati dal 2025-01-01) con CUP, costi, finanziamenti, stato | Quando servono i singoli CUP filtrabili | medio |
| `anncsu_civico_search` | Query puntuali su civici con filtri server-side. Filtri: `odonimo` (substring), `civico` (esatto). Default limit 50, max 500 | Verifica esistenza/coordinate di un civico specifico | piccolo |

**Regola pratica decision tree**:

```
User chiede dato singolo comune?
├─ Domanda puntuale o confronto tra comuni? → comune_kpi
├─ Dettaglio (mappe, top liste, time series)? → comune_dashboard
├─ Singoli CUP opere pubbliche? → comune_opere_dettaglio
└─ Civico/strada specifica? → anncsu_civico_search
```

## Schema `comune_kpi` (output ~2.5KB)

Risposta strutturata in 22 gruppi tematici. Ogni gruppo contiene 2-7 campi scalari. Campi mancanti sono `null` espliciti (schema stabile).

```json
{
  "_generated_at": "2026-05-15T08:00:04+00:00",
  "_etl_version": "0.1.0",
  "_missing": [],
  "anagrafica": {"istat", "nome", "provincia_sigla", "regione", "codice_fiscale", "codice_catastale"},
  "demografia": {"popolazione", "maschi", "femmine", "eta_media", "indice_vecchiaia", "indice_dipendenza", "riferimento"},
  "istruzione_profilo": {"anno", "pct_terziario", "pct_diploma_oltre"},
  "lavoro_profilo": {"anno", "tasso_occupazione", "tasso_disoccupazione", "tasso_attivita"},
  "redditi_mef": {"anno_fiscale", "n_contribuenti", "reddito_medio_eur", "imposta_netta_media_eur"},
  "scuole_miur": {"n_scuole", "anno_scolastico", "scuole_per_1000_ab"},
  "contratti_anac": {"n_aggiudicazioni", "importo_totale_eur", "importo_per_abitante_eur", "ultima_aggiudicazione"},
  "opere_bdap": {"n_progetti", "importo_totale_eur", "importo_per_abitante_eur"},
  "pnrr": {"n_progetti", "n_concluso", "n_in_corso", "importo_assegnato_eur", "importo_per_abitante_eur"},
  "siope": {"anno", "totale_uscite_eur", "uscite_per_abitante_eur"},
  "patrimonio_pa": {"n_immobili", "n_fabbricati", "n_terreni", "superficie_totale_mq"},
  "ambiente": {"superficie_kmq", "consumo_suolo_pct", "raccolta_differenziata_pct", "rifiuti_kg_per_abitante"},
  "aria_ispra": {"ha_stazione", "anno", "pm10_media", "pm25_media", "no2_media"},
  "turismo": {"anno", "totale_strutture", "totale_letti", "indice_turisticita_per_100ab"},
  "veicoli_aci": {"anno", "totale_veicoli", "autovetture", "tasso_motorizzazione_per_1000_ab", "pct_inquinanti"},
  "banda_larga_agcom": {"famiglie_residenti", "copertura_ftth_pct", "copertura_ftth_20m_pct", "data_rilevazione"},
  "ricarica_ev_pun": {"n_totale", "n_attivi", "pct_attivi", "potenza_totale_kw", "punti_per_1000_ab"},
  "carburanti_mimit": {"n_impianti", "n_pompe_bianche", "prezzo_medio_benzina_self", "prezzo_medio_gasolio_self", "impianti_per_1000_ab"},
  "civici_anncsu": {"n_strade", "n_civici", "pct_geo_ref", "snapshot_date"},
  "terzo_settore_runts": {"n_enti_totali", "n_5x1000", "pct_5x1000", "enti_per_1000_ab", "snapshot_date"},
  "sanita_mds": {"n_farmacie", "n_parafarmacie", "n_ospedali", "posti_letto_ospedalieri", "farmacie_per_1000_ab"}
}
```

**Importi finanziari**: sempre in **euro interi**. Versione **pro-capite o per-1000-abitanti** disponibile dove ha senso comparabile (ANAC, BDAP, PNRR, SIOPE, scuole, ricarica EV, carburanti, RUNTS, farmacie).

**Trend YoY**: non inclusi in `comune_kpi`. Per delta o serie storiche usa `comune_dashboard.redditi.anni[*]` o `comune_dashboard.siope.per_anno[*]`.

## Workflow patterns

### Pattern 1: query puntuale singolo comune

User: *"Qual è il reddito medio a Lecce?"*

```
1. search_comune("Lecce") → istat="075035"
2. comune_kpi(istat_code="075035") → leggi redditi_mef.reddito_medio_eur
```

### Pattern 2: confronto N comuni

User: *"Compara Verona, Bari e Lecce su PNRR e banda larga"*

```
1. search_comune("Verona") → "023091"
2. search_comune("Bari") → "072006"
3. search_comune("Lecce") → "075035"
4. comune_kpi("023091"), comune_kpi("072006"), comune_kpi("075035")
5. Estrai pnrr.importo_per_abitante_eur e banda_larga_agcom.copertura_ftth_pct
   da ciascuna risposta. Componi tabella.
```

**Vantaggio kpi vs dashboard**: 3 chiamate × ~620 token = ~1.860 token totali invece di ~750.000 con `comune_dashboard`.

### Pattern 3: vista approfondita singolo comune

User: *"Mostrami i top 5 contratti di Bari per importo"*

```
1. search_comune("Bari") → "072006"
2. comune_dashboard(istat_code="072006") → leggi anac.top_cpv per dettaglio
```

Qui serve `comune_dashboard` perché `comune_kpi` non ha array (solo conteggi aggregati).

### Pattern 4: civico specifico

User: *"Quale è la quota altimetrica di Via dei Mille civico 5 a Lecce?"*

```
1. search_comune("Lecce") → "075035"
2. anncsu_civico_search(istat_code="075035", odonimo="MILLE", civico="5")
```

### Pattern 5: opere pubbliche dettaglio

User: *"Quali sono le opere PNRR in corso a Matera con CUP?"*

```
1. search_comune("Matera") → "077014"
2. comune_opere_dettaglio(istat_code="077014") → filtra per stato="ATTIVO"
```

## Caveat per sezione

- **anac**: copre solo i comuni che sono *stazioni appaltanti* nel periodo monitorato. Comuni piccoli senza aggiudicazioni → `anac: null` o counter zero. La data `ultima_aggiudicazione` indica la freschezza reale del dato.
- **aria_ispra**: solo 604 comuni hanno stazione di rilevazione. Se `ha_stazione: false`, le medie PM10/PM2.5/NO2 sono null.
- **immobili_pa**: snapshot 2022 (MEF DE Censimento Beni Immobili). Dato non aggiornato annualmente.
- **anncsu**: snapshot Agenzia Entrate. Coverage geografica varia per comune.
- **runts**: include 6 sezioni ETS (ODV/APS/EF/IS/SMS/ETS). `pct_5x1000` indica enti accreditati al 5x1000.
- **pun**: punti di ricarica EV dichiarati al GSE. `pct_attivi` < 100% normale (impianti in collaudo).
- **banda_larga_agcom**: copertura DESI = % famiglie raggiunte da almeno una linea FTTH. `copertura_ftth_20m_pct` = % raggiunte a velocità ≥ 1 Gbps.

## Endpoint REST aggiuntivi

Oltre ai tool MCP, il Worker espone:

- `GET /data/anncsu_full/<istat>.json` — dataset completo civici per comune (per Roma 515.815, Milano ~280.000). Usalo solo se serve davvero il dato completo; per query puntuali usa `anncsu_civico_search` che evita di buttare 500k civici nel context LLM.

## Codici ISTAT di test consigliati

| Codice | Comune | Note |
|---|---|---|
| 075035 | Lecce | comune medio, ampia copertura dati |
| 072006 | Bari | capoluogo Puglia |
| 058091 | Roma | metropoli, dati molto ricchi |
| 015146 | Milano | metropoli nord |
| 077014 | Matera | medio sud, patrimonio UNESCO |
| 007021 | Cogne | piccolo comune montano |
| 016234 | Ponte San Pietro | comune medio-piccolo |
